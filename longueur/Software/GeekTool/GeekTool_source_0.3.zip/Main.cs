using System;
using System.Data;
using System.Text;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Configuration;
using System.ComponentModel;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Common;

namespace GeekTool
{
	public partial class Main : Form
	{
		// Import some Win32 methods for setting the form at the very back.
		[DllImport("User32.dll")]
		public static extern Int32 FindWindow(String lpClassName, String lpWindowName);
		[DllImport("User32.dll")]
		static extern int SetParent(int hWndChild, int hWndNewParent);

		// Constants.
		private const string firstGroupConst = "{0}";

		// Member variables to store some in-house stuff.
		private bool isMouseDown = false;
		private int fadeInOpacity = 0;
		private Point downLocation;
		private Point downMousePosition;
		private Logger logger;
		private Timer timer = new Timer();
		private Timer fadeInTimer = new Timer();
		private Timer fadeOutTimer = new Timer();
		private Regex displayRegex;
		private Regex displayCharsToReplaceRegex;
		Regex explicitGroupsRegex = new Regex(@"(\{[^0]+\})", RegexOptions.Compiled);

		// Settings.
		private int timerInterval = 5000;
		private int xPos = 0;
		private int yPos = 0;
		private int width = 0;
		private int height = 0;
		private int opacity = 100;
		private Color backgroundColor = new Color();
		private Color fontColor = new Color();
		private string fileName = string.Empty;
		private string fileArgs = string.Empty;
		private string logFileName = "log.txt";
		private string fontFamily = "Courier New";
		private int fontSize = 10;
		private bool lockPosition = false;
		private string displayRegexStr = string.Empty;
		private string displayTemplate = string.Empty;
		string displayCharsToReplaceRegexStr = "\n|\r";

		/// <summary>
		/// The main access point of the program.
		/// </summary>
		public Main()
		{
			try
			{
				// Initialize VS designer stuff.
				InitializeComponent();

				// Wire up when the form gets activated..
				this.Activated += new EventHandler(Main_Activated);

				// Wire up our mouse events.
				textLabel.MouseMove += new MouseEventHandler(mouseMove);
				textLabel.MouseUp += new MouseEventHandler(mouseUp);
				textLabel.MouseClick += new MouseEventHandler(mouseClick);

				// Set our opacity to 0 when the form first loads,
				// and then wire up our fade in.
				base.Opacity = 0.0;
				fadeInTimer.Interval = 3;
				fadeInTimer.Tick += new EventHandler(fadeInTimer_Tick);
				fadeInTimer.Start();

				// Wire up the fade out tricks.
				fadeOutTimer.Interval = 3;
				fadeOutTimer.Tick += new EventHandler(fadeOutTimer_Tick);

				// Grab our settings.
				getSettings();

				// Set our settings.
				setSettings();

				// If the timer is sufficient, wire it up and start it. Otherwise throw a big, fat error.
				if (timerInterval > 0)
				{
					timer.Tick += new EventHandler(timer_Tick);
					startTimer();
				}
				else
				{
					throw new Exception("The timer interval must be higher than 0.");
				}
			}
			// Catch any errors that we get from missing settings.
			catch (InvalidSettingsException ex)
			{
				// Cleanup our events and stop some timers.
				cleanup();

				// Set our size to some default.
				Size size = new Size(300, 300);

				// Set the rest of our form values to some nice defaults.
				base.Location = new Point(0, 0);
				base.Size = size;
				textLabel.Size = size;
				base.BackColor = Color.White;
				base.ForeColor = Color.Red;
				base.Font = new Font(FontFamily.GenericMonospace, 10);
				
				// Write our error message to the screen 
				// (luckily the settings reader gives us some readable errors).
				writeToScreen(ex.Message);
			}
			// Catch all other errors here and write them to the screen and to the log file.
			catch (Exception ex)
			{
				// Write the exception to the log file and to the screen if possible.
				string exception = ex.Message;

				writeToScreen(exception);

				if (logger != null)
				{
					logger.Log(exception);
				}
			}
		}

		/// <summary>
		/// Cleans up our wired up events and stops the main timer.
		/// </summary>
		private void cleanup()
		{
			// Unregister all of our wired events.
			this.Activated -= Main_Activated;
			textLabel.MouseMove -= mouseMove;
			textLabel.MouseUp -= mouseUp;

			// Stop the main timer.
			stopTimer();
		}

		/// <summary>
		/// Called when the fade out tick is fired.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void fadeOutTimer_Tick(object sender, EventArgs e)
		{
			// If we aren't transperant, keep going.
			if (opacity > 0)
			{
				opacity--;
				base.Opacity = opacity * 0.01;
			}
			// Cleanup after ourselves and exit the program.
			else
			{
				cleanup();

				// Un-register the fade out events.
				fadeOutTimer.Tick -= fadeOutTimer_Tick;
				fadeOutTimer.Stop();
				fadeOutTimer.Enabled = false;

				Application.Exit();
			}
		}

		/// <summary>
		/// Called when the fade in tick is fired.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void fadeInTimer_Tick(object sender, EventArgs e)
		{
			// If we aren't at the desired opcaity, keep going.
			if (fadeInOpacity < opacity)
			{
				fadeInOpacity++;
				base.Opacity = fadeInOpacity * 0.01;
			}
			// We made it! So, cleanup this timer.
			else
			{
				fadeInTimer.Stop();
				fadeInTimer.Enabled = false;
				fadeInTimer.Tick -= fadeInTimer_Tick;
			}
		}

		/// <summary>
		/// Get the settings from the app.config file.
		/// </summary>
		private void getSettings()
		{
			try
			{
				// Generate the settings from our config file.
				AppSettingsReader settings = new AppSettingsReader();

				// Do a grabby grab for our settings.
				xPos = (int)settings.GetValue("xPos", typeof(int));

				// Give our users a favor and let them use negative numbers for positioning.
				if (xPos < 0)
				{
					xPos = SystemInformation.WorkingArea.Width + xPos;
				}

				yPos = (int)settings.GetValue("yPos", typeof(int));

				if (yPos < 0)
				{
					yPos = SystemInformation.WorkingArea.Height + yPos;
				}

				width = (int)settings.GetValue("width", typeof(int));
				height = (int)settings.GetValue("height", typeof(int));
				opacity = (int)settings.GetValue("opacity", typeof(int));
				timerInterval = (int)settings.GetValue("timerInterval", typeof(int));
				fileName = (string)settings.GetValue("fileName", typeof(string));
				fileArgs = (string)settings.GetValue("fileArgs", typeof(string));
				logFileName = (string)settings.GetValue("logFileName", typeof(string));
				fontFamily = (string)settings.GetValue("fontFamily", typeof(string));
				fontSize = (int)settings.GetValue("fontSize", typeof(int));
				lockPosition = (bool)settings.GetValue("lockPosition", typeof(bool));
				displayRegexStr = (string)settings.GetValue("displayRegex", typeof(string));
				displayTemplate = (string)settings.GetValue("displayTemplate", typeof(string));
				displayCharsToReplaceRegexStr = (string)settings.GetValue("displayCharsToReplaceRegex", typeof(string));

				// Do some conversion from a comma-delimited stirng of RGB values to an actual color.
				string backgroundColorStr = (string)settings.GetValue("backgroundColor", typeof(string));
				backgroundColor = General.ConvertStringToColor(backgroundColorStr);

				string fontColorStr = (string)settings.GetValue("fontColor", typeof(string));
				fontColor = General.ConvertStringToColor(fontColorStr);
			}
			catch (Exception ex)
			{
				throw new InvalidSettingsException("Some settings are incorrect or missing: " + ex.Message);
			}
		}

		/// <summary>
		/// Writes the message to the form.
		/// </summary>
		/// <param name="message">The text to write.</param>
		/// <param name="append">Whether to append the message or not.</param>
		private void writeToScreen(string message, bool append)
		{
			// Whether to append the output, or overwrite the old output.
			if (append)
			{
				textLabel.Text += message;
			}
			else
			{
				textLabel.Text = message;
			}
		}

		/// <summary>
		/// Writes the message to the form, overwriting any old output.
		/// </summary>
		/// <param name="message">The text to write.</param>
		private void writeToScreen(string message)
		{
			writeToScreen(message, false);
		}

		/// <summary>
		/// Starts the process which is generating the output.
		/// </summary>
		private void startProcess()
		{
			// Generate a new process that will cleanup after itself.
			using (Process process = new Process())
			{
				// Set the file information about the process.
				process.StartInfo.FileName = fileName;

				if (!string.IsNullOrEmpty(fileArgs))
				{
					process.StartInfo.Arguments = fileArgs;
				}

				// These have to be set like this so we can get the output.
				process.StartInfo.CreateNoWindow = true;
				process.StartInfo.RedirectStandardError = true;
				process.StartInfo.RedirectStandardOutput = true;
				process.StartInfo.UseShellExecute = false;

				try
				{
					process.Start();

					// Grab the standard output from the process and write it.
					string stdOutput = process.StandardOutput.ReadToEnd();
					if (!string.IsNullOrEmpty(stdOutput))
					{
						string output = parseOutput(stdOutput);
						writeToScreen(output);
					}

					// Grab the error output from the process and write it.
					string stdError = process.StandardError.ReadToEnd();
					if (!string.IsNullOrEmpty(stdError))
					{
						writeToScreen(stdError);
					}
				}
				catch (Exception ex)
				{
					// Write the exception to the log file and screen.
					string exception = ex.Message;

					writeToScreen(exception);
					logger.Log(exception);
				}
			}
		}

		/// <summary>
		/// Parses the output from the process.
		/// </summary>
		/// <param name="stdOutput">Output that we are parsing.</param>
		/// <returns>A nicely formatted string.</returns>
		private string parseOutput(string stdOutput)
		{
			// Make sure there is some regex to parse the output with.
			if (!string.IsNullOrEmpty(displayRegexStr)
				&& displayRegex != null)
			{
				StringBuilder output = new StringBuilder();
				string[] explicitGroups = { };

				// If we have a display template clean it up a little bit, 
				// and then grab the groups that are defined in the regex.
				if (!string.IsNullOrEmpty(displayTemplate))
				{
					displayTemplate = displayTemplate.Replace("\\n", Environment.NewLine);

					// Only get the group names if we are using an explicit group 
					// in the template that is not '{0}'
					if (explicitGroupsRegex.IsMatch(displayTemplate))
					{
						explicitGroups = displayRegex.GetGroupNames();
					}
				}

				// Loop over all the matches.
				foreach (Match match in displayRegex.Matches(stdOutput))
				{
					// If there are no or there is only one explicit group 
					// (there is always at least one if the regex is a match),
					// take the match and either use the default or the custom template.
					if (explicitGroups == null
						|| explicitGroups.Length <= 1)
					{
						// If there is no template just output everything with a newline at the end.
						if (string.IsNullOrEmpty(displayTemplate))
						{
							string matchValue = displayCharsToReplaceRegex.Replace(match.Value, string.Empty);

							output.Append(matchValue);
							output.Append(Environment.NewLine);
						}
						// Use the template to replace '{0}' with the whole match.
						else
						{
							string matchValue = displayCharsToReplaceRegex.Replace(match.Value, string.Empty);

							string tmpOutput = displayTemplate.Replace(firstGroupConst, matchValue);
							output.Append(tmpOutput);
						}
					}
					// The template has some explicit groups that aren't '{0}',
					// we should be nice and try to do what they want.
					else
					{
						string tmpOutput = displayTemplate;
						string matchValue = string.Empty;

						// Loop over all of the explicit groups and replace any of 
						// the explicit groups in the template with their real values from the match.
						foreach (string name in explicitGroups)
						{
							matchValue = match.Groups[name].Value;

							if (!string.IsNullOrEmpty(matchValue))
							{
								matchValue = displayCharsToReplaceRegex.Replace(matchValue, string.Empty);

								tmpOutput = tmpOutput.Replace("{" + name + "}", matchValue);
							}
						}

						// As long as our result isn't the same as the template, let's keep it.
						if (!tmpOutput.Equals(displayTemplate))
						{
							output.Append(tmpOutput);
						}
					}
				}

				// Return our output string.
				return output.ToString();
			}
			
			// Appearantly we are going to just return the standard out untouched.
			return stdOutput;
		}

		#region set-up
		/// <summary>
		/// Take our settings and implement them.
		/// </summary>
		private void setSettings()
		{
			// Determine our location by the X and Y position.
			Point location = new Point(xPos, yPos);

			// Setup the logger.
			logger = new Logger(logFileName);

			// If we want to lock, call a Win32 API to do it.
			if (lockPosition)
			{
				int pWnd = FindWindow("Progman", null);
				int tWnd = this.Handle.ToInt32();

				SetParent(tWnd, pWnd);
			}

			// Setup our main regex. 
			if (!string.IsNullOrEmpty(displayRegexStr))
			{
				displayRegex = new Regex(displayRegexStr, RegexOptions.Compiled | RegexOptions.Multiline | RegexOptions.ExplicitCapture);
			}

			// Setup the regex of the characters we want to get rid of.
			if (!string.IsNullOrEmpty(displayCharsToReplaceRegexStr))
			{
				displayCharsToReplaceRegex = new Regex(displayCharsToReplaceRegexStr, RegexOptions.Compiled);
			}

			// Setup the form.
			base.BackColor = backgroundColor;
			base.ForeColor = fontColor;
			base.Font = new Font(fontFamily, fontSize);
			base.Location = location;			

			// Appearantly WinForms can't be any smaller than 112x27.
			if (width < 112)
			{
				width = 112;
			}

			if (height < 27)
			{
				height = 27;
			}

			// Set our size.
			Size size = new Size(width, height);
			this.ClientSize = size;
			textLabel.Size = size;
		}
		#endregion

		/// <summary>
		/// Start the timer.
		/// </summary>
		private void startTimer()
		{
			if (timer.Enabled)
			{
				timer.Stop();
				timer.Enabled = false;
			}

			timer.Interval = timerInterval;
			timer.Enabled = true;
			timer.Start();
		}

		/// <summary>
		/// Stop the timer.
		/// </summary>
		private void stopTimer()
		{
			if (timer.Enabled)
			{
				timer.Enabled = false;
				timer.Stop();
			}
		}

		#region events
		/// <summary>
		/// Event which gets fired when the form is activated.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Main_Activated(object sender, EventArgs e)
		{
			// Send this bad boy to back of class.
#if !DEBUG
			this.SendToBack();
#endif
		}

		/// <summary>
		/// Event which gets fired when the timer interval elapses.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void timer_Tick(object sender, EventArgs e)
		{
			startProcess();
		}

		/// <summary>
		/// Event which gets fired when the exit menu item is selected.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void exitMenuItem_Click(object sender, EventArgs e)
		{
			fadeOutTimer.Start();
		}

		/// <summary>
		/// Event which gets fired when the mouse moves over the form or textlabel.
		/// </summary>
		/// <param name="sender">Sender.</param>
		/// <param name="e">Arguments.</param>
		private void mouseMove(object sender, MouseEventArgs e)
		{
			// Lock the form if this event gets fired.
			lock (this)
			{
				// We can safely ignore the rest if we are locked.
				if (!lockPosition)
				{
					// Only worry about left button clicks.
					if (e.Button == MouseButtons.Left)
					{
						if (isMouseDown)
						{
							// Change our cursor.
							this.Cursor = Cursors.SizeAll;

							// Stop the main timer thread.
							stopTimer();

							// Figure out our location and update orm accordingly.
							Point mousePos = Form.MousePosition;
							Point location = downLocation;

							location.X = location.X + (mousePos.X - downMousePosition.X);
							location.Y = location.Y + (mousePos.Y - downMousePosition.Y);

							base.Location = location;

							// Output the location to the screen.
							string locationStr = string.Format("x: {0}; y: {1}",
								location.X,
								location.Y);

							writeToScreen(locationStr);
						}
						else
						{
							downLocation = base.Location;
							downMousePosition = Form.MousePosition;
							isMouseDown = true;
						}
					}
					else
					{
						isMouseDown = false;
					}
				}
			}
		}

		/// <summary>
		/// Event which gets fired when the mouse click is up when on the form or textlabel.
		/// </summary>
		/// <param name="sender">Sender.</param>
		/// <param name="e">Arguments.</param>
		private void mouseUp(object sender, MouseEventArgs e)
		{
			lock (this)
			{
				if (!lockPosition)
				{
					Point location = base.Location;

					if (location.X != xPos
						|| location.Y != yPos)
					{
						xPos = location.X;
						yPos = location.Y;

						// TODO: Save these values to app.config.
					}

					if (!timer.Enabled)
					{
						timer.Enabled = true;
						timer.Start();

						writeToScreen("Refreshing...");
					}

					this.Cursor = Cursors.Default;
				}
			}
		}

		/// <summary>
		/// Event which gets fired when the mouse clicks on the form or textlabel.
		/// </summary>
		/// <param name="sender">Sender.</param>
		/// <param name="e">Arguments.</param>
		private void mouseClick(object sender, MouseEventArgs e)
		{
			// Show our context menu on right button clicks.
			if (e.Button == MouseButtons.Right)
			{
				contextMenuStrip.Show(Form.MousePosition.X, Form.MousePosition.Y);
			}
		}
		#endregion

		#region overrides
		/// <summary>
		/// Override for when the mouse moves over the form.
		/// </summary>
		/// <param name="e">Arguments.</param>
		protected override void OnMouseMove(MouseEventArgs e)
		{
			// Call our custom mouse move method.
			mouseMove(null, e);
			base.OnMouseMove(e);
		}

		/// <summary>
		/// Override for when the mouse click is up on the form.
		/// </summary>
		/// <param name="e"></param>
		protected override void OnMouseUp(MouseEventArgs e)
		{
			// Call our custom mouse up method.
			mouseUp(null, e);
			base.OnMouseUp(e);
		}

		/// <summary>
		/// Override for when the mouse clicks on the form.
		/// </summary>
		/// <param name="e"></param>
		protected override void OnMouseClick(MouseEventArgs e)
		{
			// Call our custom mouse click method.
			mouseClick(null, e);
			base.OnMouseClick(e);
		}
		#endregion
	}
}