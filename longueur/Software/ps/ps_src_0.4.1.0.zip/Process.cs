using System;
using System.Management;

namespace ps
{
	public class Process
	{
		public const string IDLE = "Idle";
		public const string SYSTEM = "System";

		private string caption;
		private int creatingProcessID;
		private string description;
		private long elapsedTime;
		private long frequency_Object;
		private long frequency_PerfTime;
		private long frequency_Sys100NS;
		private int handleCount;
		private int idProcess;
		private long ioDataOperationsPerSec;
		private long ioOtherOperationsPerSec;
		private long ioReadBytesPerSec;
		private long ioReadOperationsPerSec;
		private long ioWriteBytesPerSec;
		private long ioWriteOperationsPerSec;
		private long ioDataBytesPerSec;
		private long ioOtherBytesPerSec;
		private string name;
		private int pageFaultsPerSec;
		private long pageFileBytes;
		private long pageFileBytesPeak;
		private long percentPrivilegedTime;
		private long percentProcessorTime;
		private long percentUserTime;
		private int poolNonpagedBytes;
		private int poolPagedBytes;
		private int priorityBase;
		private long privateBytes;
		private int threadCount;
		private long timestamp_Object;
		private long timestamp_PerfTime;
		private long timestamp_Sys100NS;
		private long virtualBytes;
		private long virtualBytesPeak;
		private long workingSet;
		private long workingSetPeak;

		public Process()
		{
		}

		public Process(ManagementBaseObject mbo)
		{
			this.Caption = (mbo.Properties[Column.CAPTION] != null && mbo.Properties[Column.CAPTION].Value != null) ? mbo.Properties[Column.CAPTION].Value.ToString() : string.Empty;
			this.CreatingProcessID = Convert.ToInt32(mbo.Properties[Column.CREATING_PROCESS_ID].Value);
			this.Description = (mbo.Properties[Column.DESCRIPTION] != null && mbo.Properties[Column.DESCRIPTION].Value != null) ? mbo.Properties[Column.DESCRIPTION].Value.ToString() : string.Empty;
			this.ElapsedTime = Convert.ToInt64(mbo.Properties[Column.ELAPSED_TIME].Value);
			this.Frequency_Object = Convert.ToInt64(mbo.Properties[Column.FREQUENCY_OBJECT].Value);
			this.Frequency_PerfTime = Convert.ToInt64(mbo.Properties[Column.FREQUENCY_PERF_TIME].Value);
			this.Frequency_Sys100NS = Convert.ToInt64(mbo.Properties[Column.FREQUENCY_SYS_100_NS].Value);
			this.HandleCount = Convert.ToInt32(mbo.Properties[Column.HANDLE_COUNT].Value);
			this.IDProcess = Convert.ToInt32(mbo.Properties[Column.ID_PROCESS].Value);
			this.IODataBytesPerSec = Convert.ToInt64(mbo.Properties[Column.IO_DATA_BYTES_PER_SEC].Value);
			this.IODataOperationsPerSec = Convert.ToInt64(mbo.Properties[Column.IO_DATA_OPERATIONS_PER_SEC].Value);
			this.IOOtherBytesPerSec = Convert.ToInt64(mbo.Properties[Column.IO_OTHER_BYTES_PER_SEC].Value);
			this.IOOtherOperationsPerSec = Convert.ToInt64(mbo.Properties[Column.IO_OTHER_OPERATIONS_PER_SEC].Value);
			this.IOReadBytesPerSec = Convert.ToInt64(mbo.Properties[Column.IO_READ_BYTES_PER_SEC].Value);
			this.IOReadOperationsPerSec = Convert.ToInt64(mbo.Properties[Column.IO_READ_OPERATIONS_PER_SEC].Value);
			this.IOWriteBytesPerSec = Convert.ToInt64(mbo.Properties[Column.IO_WRITE_BYTES_PER_SEC].Value);
			this.IOWriteOperationsPerSec = Convert.ToInt64(mbo.Properties[Column.IO_WRITE_OPERATIONS_PER_SEC].Value);
			this.Name = mbo.Properties[Column.NAME].Value.ToString();
			this.PageFaultsPerSec = Convert.ToInt32(mbo.Properties[Column.PAGE_FAULTS_PER_SEC].Value);
			this.PageFileBytes = Convert.ToInt64(mbo.Properties[Column.PAGE_FILE_BYTES].Value);
			this.PageFileBytesPeak = Convert.ToInt64(mbo.Properties[Column.PAGE_FILE_BYTES_PEAK].Value);
			this.PercentPrivilegedTime = Convert.ToInt64(mbo.Properties[Column.PERCENT_PRIVILEDGED_TIME].Value);
			this.PercentProcessorTime = Convert.ToInt64(mbo.Properties[Column.PERCENT_PROCESSOR_TIME].Value);
			this.PercentUserTime = Convert.ToInt64(mbo.Properties[Column.PERCENT_USER_TIME].Value);
			this.PoolNonpagedBytes = Convert.ToInt32(mbo.Properties[Column.POOL_NONPAGED_BYTES].Value);
			this.PoolPagedBytes = Convert.ToInt32(mbo.Properties[Column.POOL_PAGED_BYTES].Value);
			this.PriorityBase = Convert.ToInt32(mbo.Properties[Column.PRIORITY_BASE].Value);
			this.PrivateBytes = Convert.ToInt64(mbo.Properties[Column.PRIVATE_BYTES].Value);
			this.ThreadCount = Convert.ToInt32(mbo.Properties[Column.THREAD_COUNT].Value);
			this.Timestamp_Object = Convert.ToInt64(mbo.Properties[Column.TIMESTAMP_OBJECT].Value);
			this.Timestamp_PerfTime = Convert.ToInt64(mbo.Properties[Column.TIMESTAMP_PERF_TIME].Value);
			this.Timestamp_Sys100NS = Convert.ToInt64(mbo.Properties[Column.TIMESTAMP_SYS_100_NS].Value);
			this.VirtualBytes = Convert.ToInt64(mbo.Properties[Column.VIRTUAL_BYTES].Value);
			this.VirtualBytesPeak = Convert.ToInt64(mbo.Properties[Column.VIRTUAL_BYTES_PEAK].Value);
			this.WorkingSet = Convert.ToInt64(mbo.Properties[Column.WORKING_SET].Value);
			this.WorkingSetPeak = Convert.ToInt64(mbo.Properties[Column.WORKING_SET_PEAK].Value);
		}

		public bool Equals(Process process)
		{
			if (this.Id == process.Id)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		public string this[string columnName]
		{
			get
			{
				Column column = Column.GetColumn(columnName);

				if (column != null)
				{
					return column[this];
				}
				else
				{
					throw new Exception("The column name, " + columnName + " does not exist.");
				}
			}
		}

		public string Id
		{
			get
			{
				if (IDProcess > -1
					&& !string.IsNullOrEmpty(Name))
				{
					return IDProcess + "_" + Name;
				}

				return string.Empty;
			}
		}

		public string Name
		{
			get
			{
				if (string.IsNullOrEmpty(name))
				{
					name = string.Empty;
				}

				return name;
			}
			set
			{
				if (string.IsNullOrEmpty(value))
				{
					name = string.Empty;
				}
				else
				{
					name = value;
				}
			}
		}

		public int IDProcess
		{
			get { return idProcess; }
			set { idProcess = value; }
		}

		public int CreatingProcessID
		{
			get { return creatingProcessID; }
			set { creatingProcessID = value; }
		}

		public string Caption
		{
			get { return caption; }
			set { caption = value; }
		}

		public string Description
		{
			get { return description; }
			set { description = value; }
		}

		public long ElapsedTime
		{
			get { return elapsedTime; }
			set { elapsedTime = value; }
		}

		public long Frequency_Object
		{
			get { return frequency_Object; }
			set { frequency_Object = value; }
		}

		public long Frequency_PerfTime
		{
			get { return frequency_PerfTime; }
			set { frequency_PerfTime = value; }
		}

		public long Frequency_Sys100NS
		{
			get { return frequency_Sys100NS; }
			set { frequency_Sys100NS = value; }
		}

		public int HandleCount
		{
			get { return handleCount; }
			set { handleCount = value; }
		}

		public long IODataOperationsPerSec
		{
			get { return ioDataOperationsPerSec; }
			set { ioDataOperationsPerSec = value; }
		}

		public long IOOtherOperationsPerSec
		{
			get { return ioOtherOperationsPerSec; }
			set { ioOtherOperationsPerSec = value; }
		}

		public long IOReadBytesPerSec
		{
			get { return ioReadBytesPerSec; }
			set { ioReadBytesPerSec = value; }
		}

		public long IOReadOperationsPerSec
		{
			get { return ioReadOperationsPerSec; }
			set { ioReadOperationsPerSec = value; }
		}

		public long IOWriteBytesPerSec
		{
			get { return ioWriteBytesPerSec; }
			set { ioWriteBytesPerSec = value; }
		}

		public long IOWriteOperationsPerSec
		{
			get { return ioWriteOperationsPerSec; }
			set { ioWriteOperationsPerSec = value; }
		}

		public long IODataBytesPerSec
		{
			get { return ioDataBytesPerSec; }
			set { ioDataBytesPerSec = value; }
		}

		public long IOOtherBytesPerSec
		{
			get { return ioOtherBytesPerSec; }
			set { ioOtherBytesPerSec = value; }
		}

		public int PageFaultsPerSec
		{
			get { return pageFaultsPerSec; }
			set { pageFaultsPerSec = value; }
		}

		public long PageFileBytes
		{
			get { return pageFileBytes; }
			set { pageFileBytes = value; }
		}

		public long PageFileBytesPeak
		{
			get { return pageFileBytesPeak; }
			set { pageFileBytesPeak = value; }
		}

		public long PercentPrivilegedTime
		{
			get { return percentPrivilegedTime; }
			set { percentPrivilegedTime = value; }
		}

		public long PercentProcessorTime
		{
			get { return percentProcessorTime; }
			set { percentProcessorTime = value; }
		}

		public long PercentUserTime
		{
			get { return percentUserTime; }
			set { percentUserTime = value; }
		}

		public int PoolNonpagedBytes
		{
			get { return poolNonpagedBytes; }
			set { poolNonpagedBytes = value; }
		}

		public int PoolPagedBytes
		{
			get { return poolPagedBytes; }
			set { poolPagedBytes = value; }
		}

		public int PriorityBase
		{
			get { return priorityBase; }
			set { priorityBase = value; }
		}

		public long PrivateBytes
		{
			get { return privateBytes; }
			set { privateBytes = value; }
		}

		public int ThreadCount
		{
			get { return threadCount; }
			set { threadCount = value; }
		}

		public long Timestamp_Object
		{
			get { return timestamp_Object; }
			set { timestamp_Object = value; }
		}

		public long Timestamp_PerfTime
		{
			get { return timestamp_PerfTime; }
			set { timestamp_PerfTime = value; }
		}

		public long Timestamp_Sys100NS
		{
			get { return timestamp_Sys100NS; }
			set { timestamp_Sys100NS = value; }
		}

		public long VirtualBytes
		{
			get { return virtualBytes; }
			set { virtualBytes = value; }
		}

		public long VirtualBytesPeak
		{
			get { return virtualBytesPeak; }
			set { virtualBytesPeak = value; }
		}

		public long WorkingSet
		{
			get { return workingSet; }
			set { workingSet = value; }
		}

		public long WorkingSetPeak
		{
			get { return workingSetPeak; }
			set { workingSetPeak = value; }
		}
	}
}
