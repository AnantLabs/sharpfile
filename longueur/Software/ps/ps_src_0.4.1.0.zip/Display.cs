using System;
using System.Text;
using Common;

namespace ps
{
	/// <summary>
	/// Base class for the different display modes.
	/// </summary>
	abstract class Display
	{
		// Constants.
		private const char paddingChar = ' ';

		// Protected variables.
		protected Processes processes;
		protected Columns columns;
		protected bool convertToHumanReadable;

		/// <summary>
		/// Base display constructor.
		/// </summary>
		protected Display()
		{
		}

		/// <summary>
		/// Abstract method that will be overridden in inherited classes.
		/// </summary>
		public abstract void DisplayProcesses();

		protected StringBuilder getTemplatedOutput(Process process, string template)
		{
			return getTemplatedOutput(process, template, false);
		}

		/// <summary>
		/// Uses the template to output the process information as specified.
		/// </summary>
		/// <param name="process">Process object which stores all of the information.</param>
		/// <param name="template">User-specified template which dictates how the information should be output.</param>
		/// <returns>String of the correct output.</returns>
		protected StringBuilder getTemplatedOutput(Process process, string template, bool isTableDisplay)
		{
			// There should never be a template when there is a table display.
			StringBuilder output = new StringBuilder(template);

			for (int i = 0; i < columns.Count; i++)
			{
				Column column = columns[i];
				string columnValue = process[column.Name];

				// If the column should be human-readable, make it so.
				if (this.convertToHumanReadable
					&& column.ConvertToHumanReadable)
				{
					columnValue = General.GetHumanReadableSize(columnValue);
				}

				if (isTableDisplay)
				{
					output.Append(columnValue.PadRight(column.ValueLength, paddingChar));
				}
				else
				{
					output = output.Replace("{" + i + "}", columnValue);
				}
			}

			// Replace any character codes before jumping through this hoop.
			return getReplacedOutput(output);
		}

		/// <summary>
		/// Replace any literal character code with their equivalent.
		/// </summary>
		/// <param name="output">Output string.</param>
		/// <returns>String with the correct output.</returns>
		protected StringBuilder getReplacedOutput(StringBuilder output)
		{
			return output.Replace("\\t", "\t").Replace("\\n", "\n").Replace("\\r", "\r");
		}

		#region Table display methods
		protected void getColumnLengths()
		{
			columns.ForEach(delegate(Column column)
			{
				if (column.AbbreviatedName.Length >= column.ValueLength)
				{
					column.ValueLength = column.AbbreviatedName.Length + 1;
				}
			});

			processes.ForEach(delegate(Process process)
			{
				columns.ForEach(delegate(Column column)
				{
					if (this.convertToHumanReadable
						&& column.ConvertToHumanReadable)
					{
						string columnValue = General.GetHumanReadableSize(process[column.Name]);

						if (columnValue.Length >= column.ValueLength)
						{
							column.ValueLength = columnValue.Length + 1;
						}
					}
					else
					{

						if (process[column.Name].Length >= column.ValueLength)
						{
							column.ValueLength = process[column.Name].Length + 1;
						}
					}
				});
			});
		}

		protected string getHeader()
		{
			StringBuilder output = new StringBuilder();

			columns.ForEach(delegate(Column column)
			{
				output.Append(getPaddedOutput(column.AbbreviatedName, column.ValueLength));
			});
			output.Append(Environment.NewLine);

			columns.ForEach(delegate(Column column)
			{
				output.Append(getPaddedOutput(string.Empty, column.ValueLength, '-'));
			});
			output.Append(Environment.NewLine);

			return output.ToString();
		}

		protected string getPaddedOutput(string output, int columnWidth)
		{
			return getPaddedOutput(output, columnWidth, paddingChar);
		}

		protected string getPaddedOutput(string output, int columnWidth, char paddingChar)
		{
			return output.PadRight(columnWidth, paddingChar);
		}
		#endregion
	}
}
