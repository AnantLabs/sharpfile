using System;
using System.Text;
using System.Management;
using System.Collections.Generic;

namespace ps
{
	/// <summary>
	/// Summary description for Processes
	/// </summary>
	class Processes
	{
		private List<Process> list;
		private StringBuilder query;
		private string machinename;
		private string username;
		private string password;
		private int waitInterval = 1000;		

		public Processes()
		{
			this.machinename = Environment.MachineName;
		}

		public Processes(string machinename)
		{
			this.machinename = machinename;
		}

		public Processes(string username, string password)
		{
			this.machinename = Environment.MachineName;
			this.username = username;
			this.password = password;
		}

		public Processes(string machinename, string username, string password)
		{
			this.machinename = machinename;
			this.username = username;
			this.password = password;
		}

		private Processes(List<Process> list)
		{
			this.list = list;
		}

		public void Populate(int waitInterval, StringBuilder query)
		{
			this.waitInterval = waitInterval;
			this.query = query;

			getProcesses();
		}

		#region Inherited stuff from generics
		public void Add(Process process)
		{
			this.list.Add(process);
		}

		public Process Find(Predicate<Process> match)
		{
			return this.list.Find(match);
		}

		public Processes FindAll(Predicate<Process> match)
		{
			return new Processes(this.list.FindAll(match));
		}

		public void Sort(IComparer<Process> comparer)
		{
			list.Sort(comparer);
		}

		public IEnumerator<Process> GetEnumerator()
		{
			return this.list.GetEnumerator();
		}

		public int Count
		{
			get
			{
				return this.list.Count;
			}
		}

		public void ForEach(Action<Process> action)
		{
			this.list.ForEach(action);
		}
		#endregion

		public Process this[string name]
		{
			get
			{
				return this.list.Find(delegate(Process p)
				{
					if (p.Name.Equals(name))
					{
						return true;
					}

					return false;
				});
			}
		}

		public Process this[int pid]
		{
			get
			{
				return this.list.Find(delegate(Process p)
				{
					if (p.IDProcess.Equals(pid))
					{
						return true;
					}

					return false;
				});
			}
		}

		public Process this[int pid, string name]
		{
			get
			{
				return this.list.Find(delegate(Process p)
				{
					if (p.Id.Equals(pid + "_" + name))
					{
						return true;
					}

					return false;
				});
			}
		}

		public Processes GetProcesses(int pid)
		{
			List<Process> matches = this.list.FindAll(delegate(Process p)
			{
				if (p.IDProcess.Equals(pid))
				{
					return true;
				}

				return false;
			});

			return new Processes(matches);
		}

		public Processes GetChildProcesses(int pid)
		{
			List<Process> children = this.list.FindAll(delegate(Process p)
			{
				if (p.CreatingProcessID.Equals(pid))
				{
					return true;
				}

				return false;
			});

			return new Processes(children);
		}

		#region getProcesses
		private ManagementScope setScope()
		{
			ManagementScope scope = new ManagementScope();

			if (!string.IsNullOrEmpty(this.username)
				&& !string.IsNullOrEmpty(this.password))
			{
				scope.Options.Username = username;
				scope.Options.Password = password;
			}

			// TODO: Use machinename in the path. I think.
			//scope.Path = ?

			return scope;
		}

		private void getProcesses()
		{
			this.list = new List<Process>();
			ManagementScope scope = setScope();

			// Get process info.
			ManagementObjectSearcher searcher = new ManagementObjectSearcher(scope, new WqlObjectQuery(query.ToString()));

			foreach (ManagementBaseObject mbo in searcher.Get())
			{
				Process process = new Process(mbo);
				list.Add(process);
			}

			if (this.waitInterval > 0)
			{
				getCalculatedProcesses(searcher);
			}
		}

		private void getCalculatedProcesses(ManagementObjectSearcher searcher)
		{
			if (searcher != null)
			{
				System.Threading.Thread.Sleep(this.waitInterval);

				foreach (ManagementBaseObject mbo in searcher.Get())
				{
					Process secondSampledProcess = new Process(mbo);
					int pid = secondSampledProcess.IDProcess;
					string name = secondSampledProcess.Name;

					Process firstSampledProcess = this[pid, name];

					// Calculate the value and assign it to all of the columns that should be calculated.
					if (firstSampledProcess != null)
					{
						// This value will be used for debugging purposes below.
						long firstValue = firstSampledProcess.PercentProcessorTime;
						
						firstSampledProcess.ElapsedTime = Column.CalculateValue(Column.GetColumn(Column.ELAPSED_TIME), firstSampledProcess, secondSampledProcess);
						firstSampledProcess.IODataBytesPerSec = Column.CalculateValue(Column.GetColumn(Column.IO_DATA_BYTES_PER_SEC), firstSampledProcess, secondSampledProcess);
						firstSampledProcess.IODataOperationsPerSec = Column.CalculateValue(Column.GetColumn(Column.IO_DATA_OPERATIONS_PER_SEC), firstSampledProcess, secondSampledProcess);
						firstSampledProcess.IOOtherBytesPerSec = Column.CalculateValue(Column.GetColumn(Column.IO_OTHER_BYTES_PER_SEC), firstSampledProcess, secondSampledProcess);
						firstSampledProcess.IOOtherOperationsPerSec = Column.CalculateValue(Column.GetColumn(Column.IO_OTHER_OPERATIONS_PER_SEC), firstSampledProcess, secondSampledProcess);
						firstSampledProcess.IOReadBytesPerSec = Column.CalculateValue(Column.GetColumn(Column.IO_READ_BYTES_PER_SEC), firstSampledProcess, secondSampledProcess);
						firstSampledProcess.IOReadOperationsPerSec = Column.CalculateValue(Column.GetColumn(Column.IO_READ_OPERATIONS_PER_SEC), firstSampledProcess, secondSampledProcess);
						firstSampledProcess.IOWriteBytesPerSec = Column.CalculateValue(Column.GetColumn(Column.IO_WRITE_BYTES_PER_SEC), firstSampledProcess, secondSampledProcess);
						firstSampledProcess.IOWriteOperationsPerSec = Column.CalculateValue(Column.GetColumn(Column.IO_WRITE_OPERATIONS_PER_SEC), firstSampledProcess, secondSampledProcess);
						firstSampledProcess.PageFaultsPerSec = (int)Column.CalculateValue(Column.GetColumn(Column.PAGE_FAULTS_PER_SEC), firstSampledProcess, secondSampledProcess);
						firstSampledProcess.PercentPrivilegedTime = Column.CalculateValue(Column.GetColumn(Column.PERCENT_PRIVILEDGED_TIME), firstSampledProcess, secondSampledProcess);
						firstSampledProcess.PercentProcessorTime = Column.CalculateValue(Column.GetColumn(Column.PERCENT_PROCESSOR_TIME), firstSampledProcess, secondSampledProcess);
						firstSampledProcess.PercentUserTime = Column.CalculateValue(Column.GetColumn(Column.PERCENT_USER_TIME), firstSampledProcess, secondSampledProcess);

						// Write out to a log when weird values show up for %CPU.
						if (firstSampledProcess.PercentProcessorTime > 100)
						{
							using (System.IO.StreamWriter sw = new System.IO.StreamWriter("log.txt", true))
							{
								sw.WriteLine("DEBUG: " + DateTime.Now +
														 "Name: " + name +
														 "Pid: " + pid +
														 "1st value: " + firstValue +
														 "2nd value: " + secondSampledProcess.PercentProcessorTime +
														 "Calculated value: " + firstSampledProcess.PercentProcessorTime + "\n");
							}
						}
					}
				}
			}
		}
		#endregion
	}
}
