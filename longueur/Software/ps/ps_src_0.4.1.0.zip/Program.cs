using System;
using Common;
using System.Collections;
using System.Text;
using System.Reflection;

namespace ps
{
	/// <summary>
	/// Main class of ps.
	/// </summary>
	class Program
	{
		// Settings.
		private static string queryWhereClause = string.Empty;
		private static string treeDelimiter = "  ";
		private static string outputColumns = "Name,IDProcess,PercentProcessorTime,WorkingSet";
		private static string template = "{0}\t{1}\t{2}\t{3}";
		private static string order = "PercentProcessorTime DESC";
		private static int waitInterval = 1000;
		private static bool convertToHumanReadable = true;
		private static bool isDebug = false;
		private static bool isHelp = false;
		private static bool isVerboseHelp = false;
		private static bool isTreeDisplay = false;
		private static bool isTableDisplay = true;
		
		// Member variables.
		private static StringBuilder query = new StringBuilder("SELECT * FROM Win32_PerfRawData_PerfProc_Process WHERE Name <> '_Total'");
		private static Processes processes;
		private static Columns columns;
		private static DateTime startTime;

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		/// <param name="args">Arguments to the program.</param>
		static void Main(string[] args)
		{
			try
			{
				// Grab our fancy cmd-line settings.
				getSettings(args);

				// Print out help if necessary, otherwise grab some process information.
				if (isHelp)
				{
					writeHelp();
				}
				else
				{
					// Grab our start time.
					startTime = DateTime.Now;

					// Grab the columns to display.
					getColumns();

					// Build our query statement.
					if (!string.IsNullOrEmpty(queryWhereClause))
					{
						query.Append(queryWhereClause);
					}

					// Grab info on our processes.
					processes = new Processes();
					processes.Populate(waitInterval, query);

					// Display the process information.
					displayProcesses();

					// Print out some debug information.
#if DEBUG
				isDebug = true;
#endif

					if (isDebug)
					{
						writeDebug();
					}
				}
			}
			catch (Exception ex)
			{
				if (isDebug)
				{
					Console.WriteLine(ex.Message + ex.StackTrace + ex.InnerException + ex.InnerException.StackTrace);
				}
				else
				{
					Console.WriteLine(ex.Message);
				}
			}
		}

		/// <summary>
		/// Get columns to display.
		/// </summary>
		private static void getColumns()
		{
			bool atLeastOneCalculatedColumn = false;
			columns = new Columns();

			// Grab all of the columns specified in our string.
			foreach (string columnName in outputColumns.Split(','))
			{
				Column column;

				// If an abbreviated name is specified, grab the the two chunks and create a new column from them.
				if (columnName.Split('=').Length > 1)
				{
					string newColumnName = columnName.Split('=')[0];
					string abbreviatedName = columnName.Split('=')[1];

					column = Column.GetColumn(newColumnName, abbreviatedName);
				}
				else
				{
					column = Column.GetColumn(columnName);
				}

				// If we have a valid column, add it to our list and flag if we have a calculated column in our midst.
				if (column != null)
				{
					columns.Add(column);

					if (!atLeastOneCalculatedColumn
							&& column.IsCalculated)
					{
						atLeastOneCalculatedColumn = true;
					}
				}
			}

			// Since we don't have any calculated columns, we don't need no stinkin' wait time.
			if (!atLeastOneCalculatedColumn)
			{
				waitInterval = 0;
			}
		}
		
		/// <summary>
		/// Get settings parsed from the command-line arguments.
		/// </summary>
		/// <param name="args">String[] of command-line arguments.</param>
		private static void getSettings(string[] args)
		{
			ArgumentParser argumentParser = new ArgumentParser(args);

			foreach (string arg in argumentParser.NonSwitchArguments)
			{
				switch (arg)
				{
					case "-h":
					case "-help":
					case "-?":
					case "--help":
					case "/?":
						isHelp = true;
						return;
					case "-hh":
						isHelp = true;
						isVerboseHelp = true;
						return;
					case "-debug":
						isDebug = true;
						break;
					case "-r":
						convertToHumanReadable = false;
						break;
					case "-t":
						isTreeDisplay = true;
						break;
				}
			}

			if (!isHelp)
			{
				foreach (string arg in argumentParser.SwitchArguments)
				{
					switch (arg)
					{
						case "-f":
							queryWhereClause = string.Format(" AND Name LIKE '{0}%'",
								argumentParser[arg]);
							break;
						case "-p":
							isTableDisplay = false;
							template = argumentParser[arg];
							break;
						case "-w":
							waitInterval = int.Parse(argumentParser[arg]);
							break;
						case "-o":
							order = argumentParser[arg];
							break;
						case "-d":
							treeDelimiter = argumentParser[arg];
							break;
						case "-c":
							outputColumns = argumentParser[arg];

							// This seems silly, but I figure I should handle it.
							if (outputColumns.Equals("all", StringComparison.OrdinalIgnoreCase))
							{
								outputColumns = columns.ToString();
							}

							break;
					}
				}
			}
		}

		/// <summary>
		/// Display the processes that we have information about. Dependent on the display mode that the user specified via command-line arguments.
		/// </summary>
		private static void displayProcesses()
		{
			if (processes.Count > 0)
			{
				Display display;
				string orderColumn = order.Split(' ')[0].Trim();
				string orderBy = order.Split(' ')[1].Trim();
				DynamicComparerType sortType = (DynamicComparerType)Enum.Parse(typeof(DynamicComparerType), orderBy);

				processes.Sort(new DynamicComparer<Process>(orderColumn, sortType));

				if (isTreeDisplay)
				{
					display = new Displays.DisplayTree(processes, columns, template, convertToHumanReadable, treeDelimiter);
				}
				else
				{
					display = new Displays.DisplayTemplate(processes, columns, template, convertToHumanReadable, isTableDisplay);
				}

				display.DisplayProcesses();
			}
			else
			{
				Console.WriteLine("There were no processes which matched your query.");
			}
		}

		/// <summary>
		/// Helper method to write the help information to the screen.
		/// </summary>
		private static void writeHelp()
		{
			Assembly assembly = Assembly.GetExecutingAssembly();

			Console.WriteLine(@"
Display the current process information.");

			Console.WriteLine("Version: " + assembly.GetName().Version.ToString());
			Console.WriteLine("Source and binaries: http://www.longueur.org/software/");

			Console.WriteLine(@"
ps.exe [[-t [-d (delimiter)] | [-o (order)] [-p (template)]] [-w (num)] [-c (columns)] [-r] [-f (filter)]] | [-h | -hh]
-t: Tree view.
-d: Delimiter to indicate another level in tree view.
	Default: ""  "".
-o: Order output.
	Default: ""PercentProcessorTime DESC"".
-p: Use a template to output the columns.
	Default: ""{0}\t{1}\t{2}\t{3}"".
-w: Wait interval in milliseconds.
	Default: 1000.
-c: Output columns. Can specify user-specific column headings.
	Default: ""Name,IDProcess,PercentProcessorTime,WorkingSet"".
	Example: ""Name=NAME,IDProcess=PID,WorkingSet=WSET"".
-r: Disable human-readable output.
-f: Filter output to certain named processes.
	Example: ""expl"" will only show processes that start with ""expl"".
-h: Help
-hh: Verbose help.");

			// Write the verbose help to the screen, including a ton of descriptions.
			if (isVerboseHelp)
			{
				Console.WriteLine(@"
Columns that can be specified (http://msdn.microsoft.com/library/default.asp?url=/library/en-us/wmisdk/wmi/win32_perfrawdata_perfproc_process.asp):
");

				foreach (Column column in Column.Columns)
				{
					if (!column.Description.Equals(string.Empty))
					{
						Console.WriteLine(column.Name + " (" + column.AbbreviatedName + ")");
						Console.WriteLine(column.Description);
						Console.WriteLine();
					}
				}
			}
		}

		/// <summary>
		/// Helper method to write out the debug information to the screen.
		/// </summary>
		private static void writeDebug()
		{
			Console.WriteLine();
			Console.WriteLine("Wait interval: " + waitInterval);
			Console.WriteLine("Time to collect data: " + (((TimeSpan)DateTime.Now.Subtract(startTime)).TotalMilliseconds - waitInterval) + " ms");
			Console.WriteLine("WMI query: " + query);
			Console.Write("Columns: " + columns.ToString());
		}
	}
}
