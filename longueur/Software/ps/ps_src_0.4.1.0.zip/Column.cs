using System;
using System.Reflection;
using System.Collections.Generic;

namespace ps
{
	/// <summary>
	/// Wrapper for the System.Reflection.PropertyInfo class w/ some other column-specific properties.
	/// </summary>
	public class Column
	{
		// http://msdn.microsoft.com/library/default.asp?url=/library/en-us/wmisdk/wmi/win32_perfrawdata_perfproc_process.asp
		// Constants.
		public const string CAPTION = "Caption";
		public const string CREATING_PROCESS_ID = "CreatingProcessID";
		public const string DESCRIPTION = "Description";
		public const string ELAPSED_TIME = "ElapsedTime";
		public const string FREQUENCY_OBJECT = "Frequency_Object";
		public const string FREQUENCY_PERF_TIME = "Frequency_PerfTime";
		public const string FREQUENCY_SYS_100_NS = "Frequency_Sys100NS";
		public const string HANDLE_COUNT = "HandleCount";
		public const string ID_PROCESS = "IDProcess";
		public const string IO_DATA_OPERATIONS_PER_SEC = "IODataOperationsPerSec";
		public const string IO_OTHER_OPERATIONS_PER_SEC = "IOOtherOperationsPerSec";
		public const string IO_READ_BYTES_PER_SEC = "IOReadBytesPerSec";
		public const string IO_READ_OPERATIONS_PER_SEC = "IOReadOperationsPerSec";
		public const string IO_WRITE_BYTES_PER_SEC = "IOWriteBytesPerSec";
		public const string IO_WRITE_OPERATIONS_PER_SEC = "IOWriteOperationsPerSec";
		public const string IO_DATA_BYTES_PER_SEC = "IODataBytesPerSec";
		public const string IO_OTHER_BYTES_PER_SEC = "IOOtherBytesPerSec";
		public const string NAME = "Name";
		public const string PAGE_FAULTS_PER_SEC = "PageFaultsPerSec";
		public const string PAGE_FILE_BYTES = "PageFileBytes";
		public const string PAGE_FILE_BYTES_PEAK = "PageFileBytesPeak";
		public const string PERCENT_PRIVILEDGED_TIME = "PercentPrivilegedTime";
		public const string PERCENT_PROCESSOR_TIME = "PercentProcessorTime";
		public const string PERCENT_USER_TIME = "PercentUserTime";
		public const string POOL_NONPAGED_BYTES = "PoolNonpagedBytes";
		public const string POOL_PAGED_BYTES = "PoolPagedBytes";
		public const string PRIORITY_BASE = "PriorityBase";
		public const string PRIVATE_BYTES = "PrivateBytes";
		public const string THREAD_COUNT = "ThreadCount";
		public const string TIMESTAMP_OBJECT = "Timestamp_Object";
		public const string TIMESTAMP_PERF_TIME = "Timestamp_PerfTime";
		public const string TIMESTAMP_SYS_100_NS = "Timestamp_Sys100NS";
		public const string VIRTUAL_BYTES = "VirtualBytes";
		public const string VIRTUAL_BYTES_PEAK = "VirtualBytesPeak";
		public const string WORKING_SET = "WorkingSet";
		public const string WORKING_SET_PEAK = "WorkingSetPeak";

		// Private members.
		private System.Reflection.PropertyInfo propertyInfo;
		private static Columns columns;
		private bool gotInfo = false;

		// Private variables for properties.
		private string name;
		private string description;
		private string abbreviatedName;
		private Type type;
		private int valueLength;
		private bool convertToHumanReadable = false;
		private CounterType counterType = CounterType.PERF_COUNTER_NOTYPE;

		/// <summary>
		/// Hidden constructor.
		/// </summary>
		private Column()
		{
		}

		/// <summary>
		/// Constructor which takes a PropertyInfo object to populate some basic information.
		/// </summary>
		/// <param name="propertyInfo">PropertyInfo which is gettings wrapped.</param>
		public Column(PropertyInfo propertyInfo)
		{
			this.propertyInfo = propertyInfo;
		}

		/// <summary>
		/// Get a value for this specific column and a specific process that is passed in.
		/// </summary>
		/// <param name="process">Process to grab the information from.</param>
		/// <returns>The value stored for the specific column of the specified process.</returns>
		public string this[Process process]
		{
			get
			{
				return propertyInfo.GetValue(process, null).ToString();
			}
		}

		/// <summary>
		/// Name of the column.
		/// </summary>
		public string Name
		{
			get
			{
				// Lazy evaluation to grab the name.
				if (this.name == null)
				{
					this.name = propertyInfo.Name;
				}

				return name;
			}
		}

		/// <summary>
		/// Type that the column is stored as.
		/// </summary>
		public Type Type
		{
			get
			{
				getInfo();
				return this.type;
			}
		}

		/// <summary>
		/// Length of the value stored in the column.
		/// </summary>
		public int ValueLength
		{
			get
			{
				return valueLength;
			}
			set
			{
				valueLength = value;
			}
		}

		public CounterType CounterType
		{
			get
			{
				return this.counterType;
			}
		}

		/// <summary>
		/// Whether or not the column should be calculated.
		/// </summary>
		public bool IsCalculated
		{
			// This should be true for the following properties:
			// ElapsedTime
			// IODataOperationsPerSec
			// IOOtherOperationsPerSec
			// IOReadBytesPerSec
			// IOReadOperationsPerSec
			// IOWriteBytesPerSec
			// IOWriteOperationsPerSec
			// IODataBytesPerSec
			// IOOtherBytesPerSec
			// PageFaultsPerSec
			// PercentPrivledgedTime
			// PercentProcessorTime
			// PercentUserTime

			get
			{
				getInfo();

				switch (this.counterType)
				{
					case CounterType.PERF_COUNTER_COUNTER:
					case CounterType.PERF_COUNTER_BULK_COUNT:
					case CounterType.PERF_100NSEC_TIMER:
					case CounterType.PERF_ELAPSED_TIME:
						return true;
					default:
						return false;
				}
			}
		}

		/// <summary>
		/// Whether the column should be human readable or not.
		/// </summary>
		public bool ConvertToHumanReadable
		{
			get
			{
				getInfo();
				return this.convertToHumanReadable;
			}
		}

		/// <summary>
		/// Abbreviated name of the column.
		/// </summary>
		public string AbbreviatedName
		{
			get
			{
				getInfo();
				return this.abbreviatedName;
			}
			private set
			{
				getInfo();
				this.abbreviatedName = value;
			}
		}

		/// <summary>
		/// Description of the column.
		/// </summary>
		public string Description
		{
			get
			{
				getInfo();
				return this.description;
			}
		}

		/// <summary>
		/// Grabs the column-specific information for the column.
		/// </summary>
		private void getInfo()
		{
			if (!gotInfo)
			{
				this.type = propertyInfo.PropertyType;

				// If we don't find the property name, just default to string.empty.
				switch (this.Name)
				{
					case CAPTION:
						this.abbreviatedName = "Cap";
						this.description = "Short textual description.";
						break;
					case CREATING_PROCESS_ID:
						this.abbreviatedName = "PPid";
						this.description = "Parent process ID.";
						break;
					case DESCRIPTION:
						this.description = "Textual description.";
						this.abbreviatedName = "Desc";
						break;
					case ELAPSED_TIME:
						this.description = "Elapsed time in seconds this process has been running.";
						this.abbreviatedName = "Etime";
						this.counterType = CounterType.PERF_ELAPSED_TIME;
						break;
					case FREQUENCY_OBJECT:
						this.description = "Frequency, in ticks per second, of Timestamp_Object.";
						this.abbreviatedName = "FObj";
						break;
					case FREQUENCY_PERF_TIME:
						this.description = "Frequency, in ticks per second, of Timestamp_Perftime.";
						this.abbreviatedName = "FPerf";
						break;
					case FREQUENCY_SYS_100_NS:
						this.description = "Frequency, in ticks per second, of Timestamp_Sys100NS (10000000).";
						this.abbreviatedName = "Fsys";
						break;
					case HANDLE_COUNT:
						this.description = "Total number of handles the process has open. This number is the sum of the handles currently open by each thread.";
						this.abbreviatedName = "Hand";
						break;
					case ID_PROCESS:
						this.abbreviatedName = "Id";
						this.description = "Unique identifier of this process.";
						break;
					case IO_DATA_BYTES_PER_SEC:
						this.description = "Rate at which the process is reading and writing bytes in I/O operations. This property counts all I/O activity generated by the process to include file, network, and device I/Os.";
						this.abbreviatedName = "IoByte";
						this.counterType = CounterType.PERF_COUNTER_BULK_COUNT; 
						break;
					case IO_DATA_OPERATIONS_PER_SEC:
						this.description = "Rate at which the process is issuing read and write I/O operations. This property counts all I/O activity generated by the process to include file, network, and device I/Os.";
						this.abbreviatedName = "IoOps";
						this.counterType = CounterType.PERF_COUNTER_BULK_COUNT;
						break;
					case IO_OTHER_BYTES_PER_SEC:
						this.description = "Rate at which the process is issuing bytes to I/O operations that don not involve data such as control operations. This property counts all I/O activity generated by the process to include file, network, and device I/Os.";
						this.abbreviatedName = "IoOByte";
						this.counterType = CounterType.PERF_COUNTER_BULK_COUNT;
						break;
					case IO_OTHER_OPERATIONS_PER_SEC:
						this.description = "Rate at which the process is issuing I/O operations that are neither a read or a write request. An example of this type of operation would be a control function. This property counts all I/O activity generated by the process to include file, network, and device I/Os.";
						this.abbreviatedName = "IoOOps";
						this.counterType = CounterType.PERF_COUNTER_BULK_COUNT;
						break;
					case IO_READ_BYTES_PER_SEC:
						this.description = "Rate at which the process is reading bytes from I/O operations. This property counts all I/O activity generated by the process to include file, network, and device I/Os.";
						this.abbreviatedName = "IoRByte";
						this.counterType = CounterType.PERF_COUNTER_BULK_COUNT;
						break;
					case IO_READ_OPERATIONS_PER_SEC:
						this.description = "Rate at which the process is issuing read I/O operations. This property counts all I/O activity generated by the process to include file, network, and device I/Os.";
						this.abbreviatedName = "IoROps";
						this.counterType = CounterType.PERF_COUNTER_BULK_COUNT;
						break;
					case IO_WRITE_BYTES_PER_SEC:
						this.description = "Rate at which the process is writing bytes to I/O operations. This property counts all I/O activity generated by the process to include file, network, and device I/Os.";
						this.abbreviatedName = "IoWByte";
						this.counterType = CounterType.PERF_COUNTER_BULK_COUNT;
						break;
					case IO_WRITE_OPERATIONS_PER_SEC:
						this.description = "Rate at which the process is issuing write I/O operations. This property counts all I/O activity generated by the process to include file, network, and device I/Os.";
						this.abbreviatedName = "IoWOps";
						this.counterType = CounterType.PERF_COUNTER_BULK_COUNT;
						break;
					case NAME:
						this.abbreviatedName = "Name";
						this.description = "Process name.";
						break;
					case PAGE_FAULTS_PER_SEC:
						this.description = "Rate of page faults by the threads executing in this process.";
						this.abbreviatedName = "PgFlt";
						this.counterType = CounterType.PERF_COUNTER_COUNTER;
						break;
					case PAGE_FILE_BYTES:
						this.description = "Current number of bytes this process has used in the paging file(s).";
						this.abbreviatedName = "Page";
						break;
					case PAGE_FILE_BYTES_PEAK:
						this.description = "Maximum number of bytes this process has used in the paging file(s).";
						this.abbreviatedName = "PgPk";
						break;
					case PERCENT_PRIVILEDGED_TIME:
						this.description = "Percentage of elapsed time that this thread has spent executing code in privileged mode.";
						this.abbreviatedName = "%P";
						this.counterType = CounterType.PERF_100NSEC_TIMER;
						break;
					case PERCENT_PROCESSOR_TIME:
						this.abbreviatedName = "%C";
						this.description = "Percentage of elapsed time that all of the threads of this process used the processor to execute instructions.";
						this.counterType = CounterType.PERF_100NSEC_TIMER;
						break;
					case PERCENT_USER_TIME:
						this.description = "Percentage of elapsed time that this process's threads have spent executing code in user mode.";
						this.abbreviatedName = "%U";
						this.counterType = CounterType.PERF_100NSEC_TIMER;
						break;
					case POOL_NONPAGED_BYTES:
						this.description = "Pool Nonpaged Bytes is the number of bytes in the nonpaged pool.";
						this.abbreviatedName = "NPgdPool";
						break;
					case POOL_PAGED_BYTES:
						this.description = "Number of bytes in the paged pool.";
						this.abbreviatedName = "PgdPool";
						break;
					case PRIORITY_BASE:
						this.description = "Current base priority of this process.";
						this.abbreviatedName = "Pri";
						break;
					case PRIVATE_BYTES:
						this.description = "Current number of bytes this process has allocated that cannot be shared with other processes.";
						this.abbreviatedName = "PB";
						this.convertToHumanReadable = true;
						break;
					case THREAD_COUNT:
						this.description = "Number of threads currently active in this process.";
						this.abbreviatedName = "Thr";
						break;
					case TIMESTAMP_OBJECT:
						this.description = "Object-defined timestamp.";
						this.abbreviatedName = "TObj";
						break;
					case TIMESTAMP_PERF_TIME:
						this.description = "High performance counter timestamp.";
						this.abbreviatedName = "TPTime";
						break;
					case TIMESTAMP_SYS_100_NS:
						this.description = "Timestamp value in 100 nanosecond units.";
						this.abbreviatedName = "";
						break;
					case VIRTUAL_BYTES:
						this.description = "Current size, in bytes, of the virtual address space that the process is using.";
						this.abbreviatedName = "VB";
						this.convertToHumanReadable = true;
						break;
					case VIRTUAL_BYTES_PEAK:
						this.description = "Maximum number of bytes of virtual address space that the process has used at any one time.";
						this.abbreviatedName = "VBP";
						break;
					case WORKING_SET:
						this.abbreviatedName = "WS";
						this.description = "Maximum number of bytes in the working set of this process at any point in time.";
						this.convertToHumanReadable = true;
						break;
					case WORKING_SET_PEAK:
						this.description = "Maximum number of bytes in the working set of this process at any point in time.";
						this.abbreviatedName = "WSP";
						break;
					default:
						this.abbreviatedName = string.Empty;
						this.description = string.Empty;
						this.counterType = CounterType.PERF_COUNTER_NOTYPE;
						break;
				}

				gotInfo = true;
			}
		}

		/// <summary>
		/// Get all of the columns.
		/// </summary>
		public static Columns Columns
		{
			get
			{
				// We can skip this if we already have a list of all of the columns.
				if (columns == null)
				{
					List<PropertyInfo> piList = new List<PropertyInfo>(typeof(Process).GetProperties());

					columns = new Columns(piList.ConvertAll<Column>(delegate(PropertyInfo pi)
					{
						return new Column(pi);
					}));

					// Need to get rid of the "Item" column because it is vestigal 
					// from the PropertyInfo of the Process object.
					if (columns[0].Name == "Item")
					{
						columns.RemoveAt(0);
					}
				}

				return columns;
			}
		}

		/// <summary>
		/// Get a column object based on the column name.
		/// </summary>
		/// <param name="columnName">Name of the column to retrieve.</param>
		/// <returns>Column object with the specified name.</returns>
		public static Column GetColumn(string columnName)
		{
			return GetColumn(columnName, null);
		}

		/// <summary>
		/// Get a column object based on the column name, and specify an abbreviated name to use instead of the default.
		/// </summary>
		/// <param name="columnName">Name of the column to retrieve.</param>
		/// <param name="abbreviatedName">Abbreviated name to use for the column.</param>
		/// <returns>Column object with the specified name and the specified abbreviated name.</returns>
		public static Column GetColumn(string columnName, string abbreviatedName)
		{
			// Grab the column w/ the specified name.
			Column column = Columns.Find(delegate(Column c)
				{
					if (c.Name == columnName)
					{
						return true;
					}

					return false;
				});

			// If the we found a column, grab it's info and update its abbreviated name.
			if (column != null)
			{
				if (!string.IsNullOrEmpty(abbreviatedName))
				{
					column.AbbreviatedName = abbreviatedName;
				}
			}

			return column;
		}

		public static long CalculateValue(Column column, Process firstSampledProcess, Process secondSampledProcess)
		{
			long x0;
			long x1;
			long y0;
			long y1;
			long tb;
			long value = 0;

			//TB: Time base (indicates the units of raw data if not used in calculation)
			//B: Base count (number of entries)
			//X0: Oldest or first sample taken (of the numerator in this case; D0 would be of the denominator)
			//X1: More recent sample
			switch (column.CounterType)
			{
				case CounterType.PERF_COUNTER_COUNTER:
				case CounterType.PERF_COUNTER_BULK_COUNT:
					//(X1-X0)/((Y1-Y0)/TB)
					x1 = long.Parse(secondSampledProcess[column.Name]);
					x0 = long.Parse(firstSampledProcess[column.Name]);
					y1 = long.Parse(secondSampledProcess[Column.TIMESTAMP_PERF_TIME]);
					y0 = long.Parse(firstSampledProcess[Column.TIMESTAMP_PERF_TIME]);
					tb = long.Parse(firstSampledProcess[Column.FREQUENCY_PERF_TIME]);
					value = (x1 - x0) / ((y1 - y0) / tb);

					break;
				case CounterType.PERF_100NSEC_TIMER:
					//100*(X1-X0)/(Y1-Y0)
					x1 = long.Parse(secondSampledProcess[column.Name]);
					x0 = long.Parse(firstSampledProcess[column.Name]);
					y1 = long.Parse(secondSampledProcess[Column.TIMESTAMP_SYS_100_NS]);
					y0 = long.Parse(firstSampledProcess[Column.TIMESTAMP_SYS_100_NS]);
					value = 100 * (x1 - x0) / (y1 - y0);

					// To accomidate multi-processor systems.
					value = value / Environment.ProcessorCount;
					
					break;
				case CounterType.PERF_ELAPSED_TIME:
					//(X1-X0)/TB
					x0 = long.Parse(firstSampledProcess[column.Name]);
					x1 = long.Parse(secondSampledProcess[column.Name]);
					tb = long.Parse(secondSampledProcess[Column.FREQUENCY_PERF_TIME]);
					value = (x1 - x0) / tb;

					break;
				//default:
					// Can't have this default case because it throws exceptions all of the time.
					//throw new Exception("Unhandled counter type: " + column.CounterType);
			}

			return value;
		}
	}
}