using System;
using System.Collections.Generic;
using System.Text;

namespace ps.Displays
{
	/// <summary>
	/// Normal display mode. Inherits from the base display.
	/// </summary>
	class DisplayTemplate : Display
	{
		// Private members.
		private string template;
		private bool isTableDisplay;

		/// <summary>
		/// Constructor for the normal view mode.
		/// </summary>
		/// <param name="processes">Processes to output information about.</param>
		/// <param name="columns">Columns to display information about.</param>
		/// <param name="template">Template to use when displaying process information.</param>
		/// <param name="convertToHumanReadable">Whether or not the appropriate columns should be converted to human-readable output.</param>
		public DisplayTemplate(Processes processes, Columns columns, string template, bool convertToHumanReadable, bool isTableDisplay)
		{
			this.processes = processes;
			this.columns = columns;
			this.template = template;
			this.convertToHumanReadable = convertToHumanReadable;
			this.isTableDisplay = isTableDisplay;
		}

		/// <summary>
		/// Output the process information.
		/// </summary>
		public override void DisplayProcesses()
		{
			StringBuilder output = new StringBuilder();

			if (isTableDisplay)
			{
				// Make sure that tabled displays always have an empty template.
				this.template = string.Empty;

				getColumnLengths();
				output.AppendLine(getHeader());
			}

			processes.ForEach(delegate(Process process)
			{
				output.AppendLine(getTemplatedOutput(process, template, isTableDisplay).ToString());
			});

			Console.Write(output.ToString());
		}
	}
}
