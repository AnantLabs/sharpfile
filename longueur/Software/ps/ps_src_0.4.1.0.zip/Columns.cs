using System;
using System.Text;
using System.Collections.Generic;

namespace ps
{
	/// <summary>
	/// Summary description for Columns
	/// </summary>
	public class Columns
	{
		private List<Column> list;

		#region constructors
		public Columns()
		{
			this.list = new List<Column>();
		}

		public Columns(List<Column> list)
		{
			this.list = list;
		}
		#endregion
		
		public Column this[int index]
		{
			get
			{
				return this.list[index];
			}
		}
		
		public void RemoveAt(int index)
		{
			this.list.RemoveAt(index);
		}
		
		public List<Column>.Enumerator GetEnumerator()
		{
			return this.list.GetEnumerator();
		}

		public Column Find(Predicate<Column> match)
		{
			return this.list.Find(match);
		}

		public int Count
		{
			get
			{
				return this.list.Count;
			}
		}

		public void ForEach(Action<Column> action)
		{
			this.list.ForEach(action);
		}
		
		public void Add(Column column)
		{
			this.list.Add(column);
		}

		public override string ToString()
		{
			StringBuilder output = new StringBuilder();

			list.ForEach(delegate(Column c)
			{
				output.Append(c.Name);
				output.Append(",");
			});

			if (output.Length > 0)
			{
				output = output.Remove(output.Length - 1, 1);
			}

			return output.ToString();
		}
	}
}
