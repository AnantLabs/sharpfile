using System;

namespace BugZapper
{
	class Bug
	{
		private int id;
		private string summary;
		private string priority;
		private BugStatusType status;
		private DateTime eta;

		public Bug(int id, string priority, BugStatusType status, string summary, DateTime eta)
		{
			this.id = id;
			this.priority = priority;
			this.status = status;
			this.summary = summary;
			this.eta = eta;
		}

		public int Id
		{
			get
			{
				return id;
			}
		}

		public string Priority
		{
			get
			{
				return priority;
			}
		}

		public BugStatusType Status
		{
			get
			{
				return status;
			}
		}

		public string Summary
		{
			get
			{
				return summary;
			}
		}

		public DateTime ETA
		{
			get
			{
				return eta;
			}
		}
	}
}
