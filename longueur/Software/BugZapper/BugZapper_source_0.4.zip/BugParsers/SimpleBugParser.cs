using System;
using System.Collections.Generic;

namespace BugZapper.BugParsers
{
	class SimpleBugParser : BugParser
	{
		// Constants.
		private const string balloonTipTemplate = "{0} {1} bug{2}!";

		/// <summary>
		/// Simple bug parser to generate a count of the bugs in the balloon tip.
		/// </summary>
		public SimpleBugParser()
		{
		}

		protected override void createNewBugsBalloonTip(List<Bug> newBugs)
		{
			createTip(newBugs, New.ToLower());
		}

		protected override void createOverdueBugsBalloonTip(List<Bug> overdueBugs)
		{
			createTip(overdueBugs, Overdue.ToLower());
		}

		protected override void createWarningBugsBalloonTip(List<Bug> warningBugs)
		{
			createTip(warningBugs, Warning.ToLower());
		}

		protected override void createNormalBugsBalloonTip(List<Bug> normalBugs)
		{
			createTip(normalBugs, Normal.ToLower());
		}

		private void createTip(List<Bug> bugs, string type)
		{
			balloonTip.Append(string.Format(balloonTipTemplate,
					bugs.Count,
					type,
					bugs.Count > 1 ? s : string.Empty));

			balloonTip.Append(Environment.NewLine);
		}
	}
}
