using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Diagnostics;
using Common;

namespace BugZapper
{
	public partial class Main : Form
	{
		// Constants for good stuff.
		private const string appName = "BugZapper";
		private const string balloonTitleTemplate = "{0} bug{1} found!";
		private const string bugContentRegexString = @"show_bug\.cgi\?id\=(?<id>\d+).+?(?<priority>P\d).+?(?<status>NEW|ASSI).+?class=summary\>\<a.+?\>(?<summary>[^\<\/a\>]).+?class=eta\>.+?(?<eta>\d{4}\-\d{2}\-\d{2})";
		private const string s = "s";

		// For our settings.
		private int refreshTimeout = 10;
		private int numberOfDaysBeforeWarning = 3;
		private int balloonTimeout = 5000;
		private bool detailedBalloonTip = false;
		private bool showNormalBugs = false;
		private string url = string.Empty;
		private string logFileName = "log.txt";
		private LogLevelType logLevel = LogLevelType.ErrorsOnly;
		private Logger logger;

		// To "store state".
		State state = new State(new List<Bug>(), new List<Bug>(), new List<Bug>(), new List<Bug>());
		private bool forcedRefresh = true;

		// We probably only need to generate this once.
		private Regex bugsContentRegex = new Regex(bugContentRegexString, RegexOptions.Compiled);

		// Fancy events, I love 'em.
		private FileSystemWatcher fileSystemWatcher = new FileSystemWatcher();
		private Timer refreshTimer = new Timer();

		public Main()
		{
			try
			{
				// Do the magical designer-generated crap.
				InitializeComponent();

				// Watch the config file.
				setConfigWatcher();

				// Make our system tray look nice.
				setSystemTrayIcon();

				// Grab the settings from the config file.
				getSettings();

				// Start our timer to refresh our status once in a while.
				setUpTimer();

				// And... refresh our bug info.
				refreshStatus();
			}
			catch (Exception ex)
			{
				// Write the exception to the log file and popup a balloon.
				string exception = ex.Message + ex.StackTrace;

				showException(exception);
			}
		}

		private void showException(string exception)
		{
			if (logger != null)
			{
				logger.Log(exception);
			}

			showBalloonTip("Error!", exception, ToolTipIcon.Error);
		}

		/// <summary>
		/// Set our system tray icon based on our status.
		/// </summary>
		private void setSystemTrayIcon()
		{
			// Grab the icon from our resource file base on our nifty status.
			switch (state.Status)
			{
				case StatusType.GOOD:
					notifyIcon.Icon = (Icon)Resource.ResourceManager.GetObject("GoodIcon");
					break;
				case StatusType.OVERDUE:
					notifyIcon.Icon = (Icon)Resource.ResourceManager.GetObject("BadIcon");
					break;
				case StatusType.WARNED:
					notifyIcon.Icon = (Icon)Resource.ResourceManager.GetObject("WarningIcon");
					break;
			}
		}

		/// <summary>
		/// Setup a watcher to peek at our config file once in awhile.
		/// </summary>
		private void setConfigWatcher()
		{
			// What should we look at again?
			fileSystemWatcher.Path = Application.StartupPath + @"\";
			fileSystemWatcher.NotifyFilter = NotifyFilters.LastWrite;
			fileSystemWatcher.Filter = appName + ".exe.config";
			
			// Set our event.
			fileSystemWatcher.Changed += new FileSystemEventHandler(fileSystemWatcher_Changed);

			// It would be smart to actually enable this now.
			fileSystemWatcher.EnableRaisingEvents = true;
		}

		/// <summary>
		/// Grab the settings from our config file.
		/// </summary>
		private void getSettings()
		{
			// Generate the settings from our config file.
			AppSettingsReader settings = new AppSettingsReader();

			// Do a grabby grab for our settings.
			url = (string)settings.GetValue("url", typeof(string));
			refreshTimeout = (int)settings.GetValue("refreshTimeout", typeof(int));
			numberOfDaysBeforeWarning = (int)settings.GetValue("numberOfDaysBeforeWarning", typeof(int));
			balloonTimeout = (int)settings.GetValue("balloonTimeout", typeof(int));
			logLevel = (LogLevelType)Enum.Parse(typeof(LogLevelType), (string)settings.GetValue("logLevel", typeof(string)));
			detailedBalloonTip = (bool)settings.GetValue("detailedBalloonTip", typeof(bool));
			logFileName = (string)settings.GetValue("logFileName", typeof(string));
			showNormalBugs = (bool)settings.GetValue("showNormalBugs", typeof(bool));

			// Set up the logger.
			logger = new Logger(logFileName, logLevel);
		}

		/// <summary>
		/// Start the timer to refresh status.
		/// </summary>
		private void setUpTimer()
		{
			// Standard setup.
			refreshTimer.Enabled = true;
			refreshTimer.Interval = refreshTimeout * 60 * 1000;
			refreshTimer.Tick += new EventHandler(refreshTimer_Tick);

			// Actually start the timer.
			refreshTimer.Start();
		}
		
		/// <summary>
		/// Refresh the status of the bugs.
		/// </summary>
		private void refreshStatus()
		{
			if (forcedRefresh)
			{
				logger.Log("Forced refresh.", LogLevelType.MildlyVerbose);
			}
			else
			{
				logger.Log("Refreshing status.", LogLevelType.MildlyVerbose);
			}

			try
			{
				// Grab the content by scrapping the html from the url we supply.
				string content = getUrlContent(url);

				// Parse the content we just scrapped.
				parseContent(content);
			}
			catch (Exception ex)
			{
				string exception = ex.Message + ex.StackTrace;

				showException(exception);
			}
		}

		/// <summary>
		/// Parse the content that we scrapped and store our bugs in a nice object.
		/// </summary>
		/// <param name="content">Content from the web</param>
		private void parseContent(string content)
		{
			List<Bug> bugs = new List<Bug>();

			// Grab all of the bugs' data and store it.
			if (bugsContentRegex.IsMatch(content))
			{
				foreach (Match bugsContentMatch in bugsContentRegex.Matches(content))
				{
					// Grab the bug content and store it for later.
					string idValue = bugsContentMatch.Groups["id"].Value;
					string priorityValue = bugsContentMatch.Groups["priority"].Value;
					string statusValue = bugsContentMatch.Groups["status"].Value;
					string summaryValue = bugsContentMatch.Groups["summary"].Value;
					string etaValue = bugsContentMatch.Groups["eta"].Value;

					int id = !string.IsNullOrEmpty(idValue) ? int.Parse(idValue) : -1;
					string priority = !string.IsNullOrEmpty(priorityValue) ? priorityValue : "P0";
					BugStatusType status = !string.IsNullOrEmpty(statusValue) ? (BugStatusType)Enum.Parse(typeof(BugStatusType), statusValue) : BugStatusType.NEW;
					string summary = !string.IsNullOrEmpty(summaryValue) ? summaryValue : string.Empty;
					DateTime eta = DateTime.MinValue;

					// New bugs and bugs with no ETA are stored as "0000-00-00" which is pretty lame. I get around it here.
					if (!string.IsNullOrEmpty(etaValue) &&
						!etaValue.Equals("0000-00-00"))
					{
						eta = DateTime.ParseExact(etaValue, "yyyy-MM-dd", null);
					}

					// Take that bug info and create a bug nifty bug object with it.
					bugs.Add(new Bug(id, priority, status, summary, eta));

					logger.Log(string.Format("Bug {0} added.", 
						id), LogLevelType.Verbose);
				}
			}

			// Create a swell balloon tip now.
			createBalloonTip(bugs);
		}

		/// <summary>
		/// Generate some balloon tip content from our bug information.
		/// </summary>
		/// <param name="bugs">The bugs we know about.</param>
		private void createBalloonTip(List<Bug> bugs) 
		{
			// Append some data to the ballon tip if we have any bugs.
			if (bugs.Count > 0)
			{
				logger.Log(string.Format("We need to look at {0} bugs.", 
					bugs.Count), LogLevelType.Verbose);

				DateTime dateTimeNow = DateTime.Now;
				List<Bug> newBugs = new List<Bug>();
				List<Bug> warningBugs = new List<Bug>();
				List<Bug> overdueBugs = new List<Bug>();
				List<Bug> normalBugs = new List<Bug>();
				State currentState;

				// Get a count of the bugs we know about.
				foreach (Bug bug in bugs)
				{
					// New bugs.
					if (bug.Status == BugStatusType.NEW)
					{
						newBugs.Add(bug);
					}
					// Overdue bugs.
					else if (bug.ETA < dateTimeNow)
					{
						overdueBugs.Add(bug);
					} 
					// Warning bugs.
					else if (bug.ETA < dateTimeNow.AddDays(numberOfDaysBeforeWarning))
					{
						warningBugs.Add(bug);
					}
					else
					{
						normalBugs.Add(bug);
					}
				}

				logger.Log(string.Format(@"There are {0} normal bugs, {1} new bugs, {2} overdue bugs, and {3} warning bugs.",
					normalBugs.Count, 
					newBugs.Count,
					overdueBugs.Count,
					warningBugs.Count), LogLevelType.Verbose);

				// Generate our new "state".
				currentState = new State(normalBugs, newBugs, overdueBugs, warningBugs);
				
				// Only display our bugs if they have changed status or if a refresh was forced.
				if (forcedRefresh
					|| state != currentState )
				{
					BugParser bugParser;
					StringBuilder balloonTip = new StringBuilder();
					string balloonTitle = string.Empty;

					// Save our "state" no matter what.
					state = currentState;

					if (forcedRefresh)
					{
						// Not forced anymore.
						forcedRefresh = false;
					}
					else
					{
						logger.Log("Bug state has changed.", LogLevelType.MildlyVerbose);
					}

					// Display a list of bug ids, or just a count.
					if (detailedBalloonTip)
					{
						logger.Log("Create our detailed balloon tip of bugs.", LogLevelType.Verbose);
						bugParser = new BugParsers.DetailedBugParser();
					}
					else
					{
						logger.Log("Create our less-detailed balloon tip of bugs.", LogLevelType.Verbose);
						bugParser = new BugParsers.SimpleBugParser();
					}

					// Actually generate the balloon tip from our state.
					balloonTip = bugParser.CreateBalloonTip(state, showNormalBugs);
					
					// Clean up the balloon tip if neccessary.
					if (balloonTip.ToString().EndsWith(Environment.NewLine))
					{
						balloonTip = balloonTip.Remove(balloonTip.Length - 2, 2);
					}

					// Set our balloon title.
					balloonTitle = string.Format(balloonTitleTemplate,
									bugs.Count,
									bugs.Count > 1 ? s : string.Empty);

					// Show our balloon tip content.
					showBalloonTip(balloonTitle, balloonTip.ToString(), ToolTipIcon.None);
				}
			}

			// Refresh our system tray icon no matter what.
			setSystemTrayIcon();
		}

		/// <summary>
		/// Helper method to pop up the balloon tip.
		/// </summary>
		/// <param name="balloonTitle">Balloon title.</param>
		/// <param name="balloonTip">Actual content of the tip.</param>
		/// <param name="icon">Icon.</param>
		private void showBalloonTip(string balloonTitle, string balloonTip, ToolTipIcon icon)
		{
			if (balloonTip != string.Empty)
			{
				notifyIcon.ShowBalloonTip(balloonTimeout, balloonTitle, balloonTip, icon);
			}
		}

		/// <summary>
		/// Scrape the content from a url.
		/// </summary>
		/// <param name="url">Url to scrap.</param>
		/// <returns>The content.</returns>
		private string getUrlContent(string url)
		{
			logger.Log(string.Format("Grab our content from {0}.", 
				url), LogLevelType.Verbose);

			// Grab our content.
			string content = HttpUtility.GetHttpResponse(url);
			
			if (content.Length == 0)
			{
				logger.Log("There was no content. That seems fishy. Maybe check your URL?");
			} 
			else
			{
				logger.Log(string.Format("We have content of length {0}.",
					content.Length), LogLevelType.Verbose);
			}

			return content;
		}

#region Events
		void notifyIcon_BalloonTipClicked(object sender, EventArgs e)
		{
			// Open up the url in a browser.
			if (!string.IsNullOrEmpty(url))
			{
				Process process = new Process();
				process.StartInfo.FileName = url;
				process.Start();
			}
		}

		void notifyIcon_MouseClick(object sender, MouseEventArgs e)
		{
			// Show the menu for a right-click.
			if (e.Button == MouseButtons.Right)
			{
				notifyIcon.ContextMenuStrip.Show();
			}
		}

		protected override void OnResize(EventArgs e)
		{
			// Erase the app from the task tray when we minimize.
			if (this.WindowState == FormWindowState.Minimized)
			{
				this.Hide();
			}
			
			base.OnResize(e);
		}

		private void notifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
		{
			// TODO: Enable the user to open the main dialog window, when there is something there.
			//if (!this.Visible)
			//{
			//    this.Show();
			//}
			//else
			//{
			//    this.Hide();
			//}
		}

		private void exitMenuItem_Click(object sender, EventArgs e)
		{
			this.refreshTimer.Enabled = false;
			this.refreshTimer.Stop();
			this.refreshTimer.Tick -= refreshTimer_Tick;

			fileSystemWatcher.Changed -= fileSystemWatcher_Changed;

			this.Close();
			this.Dispose();

			Application.Exit();
		}

		private void refreshMenuItem_Click(object sender, EventArgs e)
		{
			forcedRefresh = true;
			refreshStatus();
		}

		private void refreshTimer_Tick(object sender, EventArgs e)
		{
			refreshStatus();
		}

		void fileSystemWatcher_Changed(object sender, FileSystemEventArgs e)
		{
			logger.Log("Config values have changed. Starting a new instance and killing our old one.");
			
			// Start new app.
			Process process = new Process();
			process.StartInfo.FileName = Application.ExecutablePath;
			process.Start();

			// Quit our app.
			Application.Exit();
		}
#endregion
	}
}