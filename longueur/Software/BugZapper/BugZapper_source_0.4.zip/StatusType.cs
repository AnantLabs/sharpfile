
namespace BugZapper
{
	/// <summary>
	/// Summary description for StatusType
	/// </summary>
	enum StatusType
	{
		GOOD,
		OVERDUE,
		WARNED
	}
}
