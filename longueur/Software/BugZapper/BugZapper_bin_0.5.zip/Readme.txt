BugZapper
Version 0.5.0.0

Scraps the Bugzilla website for project tasks and alerts when/if new bugs were added to your queue. 
The application requires a user-supplied URL looking for bug information on the page and then pops up balloon tip notifications when your bugs have changed. 
It also changes color giving some visual indication of your overall "status".

The source code for this program is available under the GPL; a copy of the license should be distributed with the executable. 
The source can be downloaded from http://www.longueur.org/software/.

There are no warranties, implicit or otherwise, included with this software. 
Run at your own risk. And read the source to send me suggestions or improvements.

Settings are as follows:
url
	The url that BugZapper should scrape. Remember that URL's should be HTML encoded.
	
refreshTimeout
	How often the webpage should be scraped.

numberOfDaysBeforeWarning
	Number of days before a task is considered a "warning" task.
	
balloonTimeout
	Length of time the balloon tip should be displayed.

logLevel
	Verbosity of the log file. 0 is the lowest, 3 is the highest.

detailedBalloonTip
	Display all of the bug ids or a tally all of the different types of bugs.

logFileName
	Log file name.
	
showNormalBugs
	Whether or not to display "normal" bugs.

ignoredIds
	Comma-delimited list of bug ids that should be ignored.