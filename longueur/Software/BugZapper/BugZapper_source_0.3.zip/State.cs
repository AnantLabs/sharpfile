using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace BugZapper
{
	/// <summary>
	/// Summary description for CurrentState
	/// </summary>
	class State
	{
		// Store the bugs.
		private List<Bug> normalBugs = new List<Bug>();
		private List<Bug> newBugs = new List<Bug>();
		private List<Bug> overdueBugs = new List<Bug>();
		private List<Bug> warningBugs = new List<Bug>();

		// Keep a hash code handy so we don't have to generate this all the time.
		private int hashCode = 0;

		/// <summary>
		/// Create an object which will keep "state" for the bugs we know about.
		/// </summary>
		/// <param name="newBugs">New bugs.</param>
		/// <param name="overdueBugs">Overdue bugs.</param>
		/// <param name="warningBugs">Warning bugs.</param>
		public State(List<Bug> normalBugs, List<Bug> newBugs, List<Bug> overdueBugs, List<Bug> warningBugs)
		{
			this.normalBugs = normalBugs;
			this.newBugs = newBugs;
			this.overdueBugs = overdueBugs;
			this.warningBugs = warningBugs;
		}

		/// <summary>
		/// Override the Equals method with our custom code.
		/// </summary>
		/// <param name="obj">Pass in a state.</param>
		/// <returns>Whether the object passed in is the same as the state.</returns>
		public override bool Equals(object obj)
		{
			State state = obj as State;

			if (state != null
				&& state == this)
			{
				return true;
			}

			return false;
		}

		/// <summary>
		/// Override the == operator with our custom equality test.
		/// </summary>
		/// <param name="state1">The first state to compare against.</param>
		/// <param name="state2">The second state to compare against.</param>
		/// <returns>Whether the two states are equal.</returns>
		public static bool operator == (State state1, State state2)
		{
			if (state1.GetHashCode() == state2.GetHashCode())
			{
				return true;
			}

			return false;
		}

		/// <summary>
		/// Override the != operator with our custom inequality test.
		/// </summary>
		/// <param name="state1">The first state to compare against.</param>
		/// <param name="state2">The second state to compare against.</param>
		/// <returns>Whether the two states are inequal.</returns>
		public static bool operator != (State state1, State state2)
		{
			if (state1.GetHashCode() != state2.GetHashCode())
			{
				return true;
			}

			return false;
		}

		/// <summary>
		/// Override the hash code method to use our custom algorithm.
		/// </summary>
		/// <returns>A unique hash of the contents of our state object.</returns>
		public override int GetHashCode()
		{
			// Generate the hash code if we haven't already.
			if (hashCode == 0)
			{
				// Append the counts.
				string hash = string.Format("{0}{1}{2}{3}",
					normalBugs.Count,
																		newBugs.Count,
																		warningBugs.Count,
																		overdueBugs.Count);

				normalBugs.ForEach(delegate(Bug bug)
				{
					hashCode = hashCode ^ bug.Id;
				});

				newBugs.ForEach(delegate(Bug bug)
													{
														hashCode = hashCode ^ bug.Id;
													});

				warningBugs.ForEach(delegate(Bug bug)
													{
														hashCode = hashCode ^ bug.Id;
													});

				overdueBugs.ForEach(delegate(Bug bug)
													{
														hashCode = hashCode ^ bug.Id;
													});

				hashCode = int.Parse(hash + hashCode.ToString());
			}

			return hashCode;
		}

		/// <summary>
		/// Normal bugs.
		/// </summary>
		public List<Bug> NormalBugs
		{
			get
			{
				return normalBugs;
			}
		}

		/// <summary>
		/// New bugs.
		/// </summary>
		public List<Bug> NewBugs
		{
			get
			{
				return newBugs;
			}
		}

		/// <summary>
		/// Overdue bugs.
		/// </summary>
		public List<Bug> OverdueBugs
		{
			get
			{
				return overdueBugs;
			}
		}

		/// <summary>
		/// Warning bugs.
		/// </summary>
		public List<Bug> WarningBugs
		{
			get
			{
				return warningBugs;
			}
		}

		/// <summary>
		/// The status is dependent on the bugs in the state.
		/// </summary>
		public StatusType Status
		{
			get
			{
				// This should be dependant on what's going down.
				if (overdueBugs.Count > 0)
				{
					return StatusType.OVERDUE;
				}
				else if (warningBugs.Count > 0)
				{
					return StatusType.WARNED;
				}

				return StatusType.GOOD;
			}
		}
	}
}
