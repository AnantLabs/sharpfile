namespace BugZapper
{
	enum BugStatusType
	{
		NEW,
		ASSI
	}
}
