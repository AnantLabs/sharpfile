using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Diagnostics;

namespace BugZapper
{
	public partial class Main : Form
	{
		// Constants for good stuff.
		private const string appName = "BugZapper";
		private const string balloonTitleTemplate = "{0} bug{1} found!";
		private const string bugContentRegexString = @"show_bug\.cgi\?id\=(?<id>\d+).+?(?<priority>P\d).+?(?<status>NEW|ASSI).+?class=summary\>\<a.+?\>(?<summary>[^\<\/a\>]).+?class=eta\>.+?(?<eta>\d{4}\-\d{2}\-\d{2})";

		// For our settings.
		private string url = "";
		private int refreshTimeout = 10;
		private int numberOfDaysBeforeWarning = 3;
		private int balloonTimeout = 5000;
		private LogLevelType logLevel = LogLevelType.ErrorsOnly;
		private bool detailedBalloonTip = false;
		private string logFileName = "log.txt";

		// To "store state".
		State state = new State(new List<Bug>(), new List<Bug>(), new List<Bug>(), new List<Bug>());
		private bool forcedRefresh = true;

		// We probably only need to generate this once.
		private Regex bugsContentRegex = new Regex(bugContentRegexString, RegexOptions.Compiled);

		// Fancy events, I love 'em.
		private FileSystemWatcher fileSystemWatcher = new FileSystemWatcher();
		private Timer refreshTimer = new Timer();

		public Main()
		{
			try
			{
				// Do the magical designer-generated crap.
				InitializeComponent();

				// Watch the config file.
				setConfigWatcher();

				// Make our system tray look nice.
				setSystemTrayIcon();

				// Grab the settings from the config file.
				getSettings();

				// Start our timer to refresh our status once in a while.
				setUpTimer();

				// And... refresh our bug info.
				refreshStatus();
			}
			catch (Exception ex)
			{
				// Write the exception to the log file and popup a balloon.
				string exception = ex.Message + ex.StackTrace;

				log(exception);
				showBalloonTip("Error!", exception, ToolTipIcon.Error);
			}
		}

		/// <summary>
		/// Helper method to open the log file and write to it.
		/// </summary>
		/// <param name="content">Content to write to the file.</param>
		private void log(string content)
		{
			log(content, LogLevelType.ErrorsOnly);
		}
		
		/// <summary>
		/// Helper method to open the log file and write to it.
		/// </summary>
		/// <param name="content">Content to write to the file.</param>
		/// <param name="logLevelType">The log level+ that will write the content.</param>
		private void log(string content, LogLevelType logLevelType)
		{
			// Append to our log file if we are the level specified or above.
			if (logLevel >= logLevelType)
			{
				using (StreamWriter sw = new StreamWriter(logFileName, true))
				{
					sw.WriteLine(DateTime.Now + ": " + content);
					sw.Flush();
				}
			}
		}

		/// <summary>
		/// Set our system tray icon based on our status.
		/// </summary>
		private void setSystemTrayIcon()
		{
			// Grab the icon from our resource file base on our nifty status.
			switch (state.Status)
			{
				case StatusType.GOOD:
					notifyIcon.Icon = (Icon)Resource.ResourceManager.GetObject("GoodIcon");
					break;
				case StatusType.OVERDUE:
					notifyIcon.Icon = (Icon)Resource.ResourceManager.GetObject("BadIcon");
					break;
				case StatusType.WARNED:
					notifyIcon.Icon = (Icon)Resource.ResourceManager.GetObject("WarningIcon");
					break;
			}
		}

		/// <summary>
		/// Setup a watcher to peek at our config file once in awhile.
		/// </summary>
		private void setConfigWatcher()
		{
			// What should we look at again?
			fileSystemWatcher.Path = Application.StartupPath + @"\";
			fileSystemWatcher.NotifyFilter = NotifyFilters.LastWrite;
			fileSystemWatcher.Filter = appName + ".exe.config";
			
			// Set our event.
			fileSystemWatcher.Changed += new FileSystemEventHandler(fileSystemWatcher_Changed);

			// It would be smart to actually enable this now.
			fileSystemWatcher.EnableRaisingEvents = true;
		}

		/// <summary>
		/// Grab the settings from our config file.
		/// </summary>
		private void getSettings()
		{
			// Generate the settings from our config file.
			AppSettingsReader settings = new AppSettingsReader();

			// Do a grabby grab for our settings.
			url = (string)settings.GetValue("url", typeof(string));
			refreshTimeout = (int)settings.GetValue("refreshTimeout", typeof(int));
			numberOfDaysBeforeWarning = (int)settings.GetValue("numberOfDaysBeforeWarning", typeof(int));
			balloonTimeout = (int)settings.GetValue("balloonTimeout", typeof(int));
			logLevel = (LogLevelType)Enum.Parse(typeof(LogLevelType), (string)settings.GetValue("logLevel", typeof(string)));
			detailedBalloonTip = (bool)settings.GetValue("detailedBalloonTip", typeof(bool));
			logFileName = (string)settings.GetValue("logFileName", typeof(string));
		}

		/// <summary>
		/// Start the timer to refresh status.
		/// </summary>
		private void setUpTimer()
		{
			// Standard setup.
			refreshTimer.Enabled = true;
			refreshTimer.Interval = refreshTimeout * 60 * 1000;
			refreshTimer.Tick += new EventHandler(refreshTimer_Tick);

			// Actually start the timer.
			refreshTimer.Start();
		}
		
		/// <summary>
		/// Refresh the status of the bugs.
		/// </summary>
		private void refreshStatus()
		{
			if (forcedRefresh)
			{
				log("Forced refresh.", LogLevelType.MildlyVerbose);
			}
			else
			{
				log("Refreshing status.", LogLevelType.MildlyVerbose);
			}
			
			// Grab the content by scrapping the html from the url we supply.
			string content = getUrlContent(url);

			// Parse the content we just scrapped.
			parseContent(content);
		}

		/// <summary>
		/// Parse the content that we scrapped and store our bugs in a nice object.
		/// </summary>
		/// <param name="content">Content from the web</param>
		private void parseContent(string content)
		{
			List<Bug> bugs = new List<Bug>();

			// Grab all of the bugs' data and store it.
			if (bugsContentRegex.IsMatch(content))
			{
				foreach (Match bugsContentMatch in bugsContentRegex.Matches(content))
				{
					// Grab the bug content and store it for later.
					string idValue = bugsContentMatch.Groups["id"].Value;
					string priorityValue = bugsContentMatch.Groups["priority"].Value;
					string statusValue = bugsContentMatch.Groups["status"].Value;
					string summaryValue = bugsContentMatch.Groups["summary"].Value;
					string etaValue = bugsContentMatch.Groups["eta"].Value;

					int id = !string.IsNullOrEmpty(idValue) ? int.Parse(idValue) : -1;
					string priority = !string.IsNullOrEmpty(priorityValue) ? priorityValue : "P0";
					BugStatusType status = !string.IsNullOrEmpty(statusValue) ? (BugStatusType)Enum.Parse(typeof(BugStatusType), statusValue) : BugStatusType.NEW;
					string summary = !string.IsNullOrEmpty(summaryValue) ? summaryValue : string.Empty;
					DateTime eta = DateTime.MinValue;

					// New bugs and bugs with no ETA are stored as "0000-00-00" which is pretty lame. I get around it here.
					if (!string.IsNullOrEmpty(etaValue) &&
						!etaValue.Equals("0000-00-00"))
					{
						eta = DateTime.ParseExact(etaValue, "yyyy-MM-dd", null);
					}

					// Take that bug info and create a bug nifty bug object with it.
					bugs.Add(new Bug(id, priority, status, summary, eta));

					log("Bug " + id + " added.", LogLevelType.Verbose);
				}
			}

			// Create a swell balloon tip now.
			createBalloonTip(bugs);
		}

		/// <summary>
		/// Generate some balloon tip content from our bug information.
		/// </summary>
		/// <param name="bugs">The bugs we know about.</param>
		private void createBalloonTip(List<Bug> bugs) 
		{
			// Append some data to the ballon tip if we have any bugs.
			if (bugs.Count > 0)
			{
				log("We need to look at " + bugs.Count + " bugs.", LogLevelType.Verbose);

				DateTime dateTimeNow = DateTime.Now;
				List<Bug> newBugs = new List<Bug>();
				List<Bug> warningBugs = new List<Bug>();
				List<Bug> overdueBugs = new List<Bug>();
				List<Bug> normalBugs = new List<Bug>();
				State currentState;

				// Get a count of the bugs we know about.
				foreach (Bug bug in bugs)
				{
					// New bugs.
					if (bug.Status == BugStatusType.NEW)
					{
						newBugs.Add(bug);
					}
					// Overdue bugs.
					else if (bug.ETA < dateTimeNow)
					{
						overdueBugs.Add(bug);
					} 
					// Warning bugs.
					else if (bug.ETA < dateTimeNow.AddDays(numberOfDaysBeforeWarning))
					{
						warningBugs.Add(bug);
					}
					else
					{
						normalBugs.Add(bug);
					}
				}

				log(@"There are " + normalBugs.Count + " normal bugs, " + newBugs.Count + " new bugs, " 
					+ overdueBugs.Count + " overdue bugs, and " + warningBugs.Count + " warning bugs.", 
					LogLevelType.Verbose);

				// Generate our new "state".
				currentState = new State(normalBugs, newBugs, overdueBugs, warningBugs);
				
				// Only display our bugs if they have changed status or if a refresh was forced.
				if (forcedRefresh
					|| state != currentState )
				{
					BugParser bugParser;
					StringBuilder balloonTip = new StringBuilder();
					string balloonTitle = string.Empty;

					// Save our "state" no matter what.
					state = currentState;

					if (forcedRefresh)
					{
						// Not forced anymore.
						forcedRefresh = false;
					}
					else
					{
						log("Bug state has changed.", LogLevelType.MildlyVerbose);
					}

					// Display a list of bug ids, or just a count.
					if (detailedBalloonTip)
					{
						log("Create our detailed balloon tip of bugs.", LogLevelType.Verbose);
						bugParser = new BugParsers.DetailedBugParser();
					}
					else
					{
						log("Create our less-detailed balloon tip of bugs.", LogLevelType.Verbose);
						bugParser = new BugParsers.SimpleBugParser();
					}

					// Actually generate the balloon tip from our state.
					balloonTip = bugParser.CreateBalloonTip(state);
					
					// Clean up the balloon tip if neccessary.
					if (balloonTip.ToString().EndsWith(Environment.NewLine))
					{
						balloonTip = balloonTip.Remove(balloonTip.Length - 2, 2);
					}

					// Set our balloon title.
					balloonTitle = string.Format(balloonTitleTemplate,
									bugs.Count,
									bugs.Count > 1 ? "s" : string.Empty);

					// Show our balloon tip content.
					showBalloonTip(balloonTitle, balloonTip.ToString(), ToolTipIcon.None);
				}
			}

			// Refresh our system tray icon no matter what.
			setSystemTrayIcon();
		}

		/// <summary>
		/// Helper method to pop up the balloon tip.
		/// </summary>
		/// <param name="balloonTitle">Balloon title.</param>
		/// <param name="balloonTip">Actual content of the tip.</param>
		/// <param name="icon">Icon.</param>
		private void showBalloonTip(string balloonTitle, string balloonTip, ToolTipIcon icon)
		{
			notifyIcon.ShowBalloonTip(balloonTimeout, balloonTitle, balloonTip, icon);
		}

		/// <summary>
		/// Scrape the content from a url.
		/// </summary>
		/// <param name="url">Url to scrap.</param>
		/// <returns>The content.</returns>
		private string getUrlContent(string url)
		{
			log("Grab our content from " + url + ".", LogLevelType.Verbose);

			// Store our content.
			StringBuilder content = new StringBuilder();
			byte[] buffer = new byte[8192];

			// Setup the objects that do the heavy lifting.
			HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
			HttpWebResponse response = (HttpWebResponse)request.GetResponse();

			// Read the stream.
			Stream resStream = response.GetResponseStream();
			string tempString = null;
			int count = 0;

			// Get all of the content from the stream.
			do
			{
				// Fill the buffer.
				count = resStream.Read(buffer, 0, buffer.Length);

				// Make sure we got some good stuff.
				if (count != 0)
				{
					// Convert bytes to a string.
					tempString = Encoding.ASCII.GetString(buffer, 0, count);
					content.Append(tempString);
				}
			}
			while (count > 0);
			
			if (content.Length == 0)
			{
				log("There was no content. That seems fishy. Maybe check your URL?");
			} 
			else
			{
				log("We have content of length " + content.Length + ".", LogLevelType.Verbose);
			}

			return content.ToString();
		}

#region Events
		void notifyIcon_BalloonTipClicked(object sender, EventArgs e)
		{
			// Open up the url in a browser.
			if (!string.IsNullOrEmpty(url))
			{
				Process process = new Process();
				process.StartInfo.FileName = url;
				process.Start();
			}
		}

		void notifyIcon_MouseClick(object sender, MouseEventArgs e)
		{
			// Show the menu for a right-click.
			if (e.Button == MouseButtons.Right)
			{
				notifyIcon.ContextMenuStrip.Show();
			}
		}

		protected override void OnResize(EventArgs e)
		{
			// Erase the app from the task tray when we minimize.
			if (this.WindowState == FormWindowState.Minimized)
			{
				this.Hide();
			}
			
			base.OnResize(e);
		}

		void notifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
		{
			if (!this.Visible)
			{
				this.Show();
			}
			else
			{
				this.Hide();
			}
		}

		private void exitMenuItem_Click(object sender, EventArgs e)
		{
			this.Close();
			this.Dispose();

			Application.Exit();
		}

		private void refreshMenuItem_Click(object sender, EventArgs e)
		{
			forcedRefresh = true;
			refreshStatus();
		}

		void refreshTimer_Tick(object sender, EventArgs e)
		{
			refreshStatus();
		}

		void fileSystemWatcher_Changed(object sender, FileSystemEventArgs e)
		{
			log("Config values have changed. Starting a new instance and killing our old one.");
			
			// Start new app.
			Process process = new Process();
			process.StartInfo.FileName = Application.ExecutablePath;
			process.Start();

			// Quit our app.
			Application.Exit();
		}
#endregion
	}
}