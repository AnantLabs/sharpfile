using System;
using System.Collections.Generic;
using System.Text;

namespace BugZapper.BugParsers
{
	class SimpleBugParser : BugParser
	{
		// Constants.
		private const string balloonTipTemplate = "{0} {1} bug{2}!";

		/// <summary>
		/// Simple bug parser to generate a count of the bugs in the balloon tip.
		/// </summary>
		public SimpleBugParser()
		{
		}

		protected override void createNewBugsBalloonTip(List<Bug> newBugs)
		{
			balloonTip.Append(string.Format(balloonTipTemplate,
					newBugs.Count,
					New.ToLower(),
					newBugs.Count > 1 ? s : string.Empty));

			balloonTip.Append(Environment.NewLine);
		}

		protected override void createOverdueBugsBalloonTip(List<Bug> overdueBugs)
		{
			balloonTip.Append(string.Format(balloonTipTemplate,
					overdueBugs.Count,
					Overdue.ToLower(),
					overdueBugs.Count > 1 ? s : string.Empty));

			balloonTip.Append(Environment.NewLine);
		}

		protected override void createWarningBugsBalloonTip(List<Bug> warningBugs)
		{
			balloonTip.Append(string.Format(balloonTipTemplate,
					warningBugs.Count,
					Warning.ToLower(),
					warningBugs.Count > 1 ? s : string.Empty));

			balloonTip.Append(Environment.NewLine);
		}
	}
}
