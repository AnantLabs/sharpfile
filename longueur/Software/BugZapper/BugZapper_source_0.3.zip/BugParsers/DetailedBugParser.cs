using System;
using System.Collections.Generic;
using System.Text;

namespace BugZapper.BugParsers
{
	class DetailedBugParser : BugParser
	{
		// Constants.
		private const string balloonTipTemplate = "{0} bug{1}: ";
		private const string comma = ", ";

		/// <summary>
		/// Detailed bug parser to generate a listing of the bug ids in the balloon tip.
		/// </summary>
		public DetailedBugParser()
		{
		}

		protected override void createNewBugsBalloonTip(List<Bug> newBugs)
		{
			// We can assume if we get here that we actually have some new bugs.
			StringBuilder newBugsBalloonTip = new StringBuilder();

			foreach (Bug bug in newBugs)
			{
				newBugsBalloonTip.Append(bug.Id);
				newBugsBalloonTip.Append(comma);
			}

			// Append our nice string to the front.
			balloonTip.Append(string.Format(balloonTipTemplate,
				New,
				newBugs.Count > 1 ? s : string.Empty));

			// Append our list of bug ids.
			newBugsBalloonTip = newBugsBalloonTip.Remove(newBugsBalloonTip.Length - 2, 2);
			balloonTip.Append(newBugsBalloonTip.ToString());
			balloonTip.Append(Environment.NewLine);
		}

		protected override void createOverdueBugsBalloonTip(List<Bug> overdueBugs)
		{
			// We can assume if we get here that we actually have some overdue bugs.
			StringBuilder overdueBugsBalloonTip = new StringBuilder();

			foreach (Bug bug in overdueBugs)
			{
				overdueBugsBalloonTip.Append(bug.Id);
				overdueBugsBalloonTip.Append(comma);
			}

			// Append our nice string to the front.
			balloonTip.Append(string.Format(balloonTipTemplate,
				Overdue,
				overdueBugs.Count > 1 ? s : string.Empty));

			// Append our list of bug ids.
			overdueBugsBalloonTip = overdueBugsBalloonTip.Remove(overdueBugsBalloonTip.Length - 2, 2);
			balloonTip.Append(overdueBugsBalloonTip.ToString());
			balloonTip.Append(Environment.NewLine);
		}

		protected override void createWarningBugsBalloonTip(List<Bug> warningBugs)
		{
			// We can assume if we get here that we actually have some warning bugs.
			StringBuilder warningBugsBalloonTip = new StringBuilder();

			foreach (Bug bug in warningBugs)
			{
				warningBugsBalloonTip.Append(bug.Id);
				warningBugsBalloonTip.Append(", ");
			}

			// Append our nice string to the front.
			balloonTip.Append(string.Format(balloonTipTemplate,
				Warning,
				warningBugs.Count > 1 ? s : string.Empty));

			// Append our list of bug ids.
			warningBugsBalloonTip = warningBugsBalloonTip.Remove(warningBugsBalloonTip.Length - 2, 2);
			balloonTip.Append(warningBugsBalloonTip.ToString());
			balloonTip.Append(Environment.NewLine);
		}
	}
}
