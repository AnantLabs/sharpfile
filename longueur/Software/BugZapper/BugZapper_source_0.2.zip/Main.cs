using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Diagnostics;

namespace BugZapper
{
	public partial class Main : Form
	{
		// Constants for good stuff.
		private const string appName = "BugZapper";

		// For our settings.
		private string url = "";
		private int refreshTimeout = 10;
		private int numberOfDaysBeforeWarning = 3;
		private int balloonTimeout = 5000;
		private LogLevelType logLevel = LogLevelType.ErrorsOnly;
		private bool displayBugIds = false;
		private string logFileName = "log.txt";

		// To "store state".
		State state = new State(-1, -1, -1);
		private bool forcedRefresh = false;

		// Balloon stuff. I guess it makes sense to just have one object floating around in memory?
		private StringBuilder balloonTip = new StringBuilder();
		private string balloonTitle = appName;

		// Fancy events, I love 'em.
		private FileSystemWatcher fileSystemWatcher = new FileSystemWatcher();
		private Timer refreshTimer = new Timer();

		public Main()
		{
			try
			{
				// Do the magical designer-generated crap.
				InitializeComponent();

				// Watch the config file.
				setConfigWatcher();

				// Make our system tray look nice.
				setSystemTrayIcon();

				// Grab the settings from the config file.
				getSettings();

				// Start our timer to refresh our status once in a while.
				setUpTimer();

				// And... refresh.
				refreshStatus();
			}
			catch (Exception ex)
			{
				// Write the exception to the log file and popup a balloon.
				string exception = ex.Message + ex.StackTrace;

				log(exception);
				showBalloonTip("Error!", exception, ToolTipIcon.Error);
			}
		}

		/// <summary>
		/// Helper method to open the log file and write to it.
		/// </summary>
		/// <param name="content">Content to write to the file.</param>
		private void log(string content)
		{
			log(content, LogLevelType.ErrorsOnly);
		}
		
		/// <summary>
		/// Helper method to open the log file and write to it.
		/// </summary>
		/// <param name="content">Content to write to the file.</param>
		/// <param name="logLevelType">The log level+ that will write the content.</param>
		private void log(string content, LogLevelType logLevelType)
		{
			// Append to our log file if we are the level specified or above.
			if (logLevel >= logLevelType)
			{
				using (StreamWriter sw = new StreamWriter(logFileName, true))
				{
					sw.WriteLine(DateTime.Now + ": " + content);
					sw.Flush();
				}
			}
		}

		/// <summary>
		/// Set our system tray icon based on our status.
		/// </summary>
		private void setSystemTrayIcon()
		{
			// Grab the icon from our resource file base on our nifty status.
			switch (state.Status)
			{
				case StatusType.GOOD:
					notifyIcon.Icon = (Icon)Resource.ResourceManager.GetObject("GoodIcon");
					break;
				case StatusType.OVERDUE:
					notifyIcon.Icon = (Icon)Resource.ResourceManager.GetObject("BadIcon");
					break;
				case StatusType.WARNED:
					notifyIcon.Icon = (Icon)Resource.ResourceManager.GetObject("WarningIcon");
					break;
			}
		}

		/// <summary>
		/// Setup a watcher to peek at our config file once in awhile.
		/// </summary>
		private void setConfigWatcher()
		{
			// What should we look at again?
			fileSystemWatcher.Path = Application.StartupPath + @"\";
			fileSystemWatcher.NotifyFilter = NotifyFilters.LastWrite;
			fileSystemWatcher.Filter = appName + ".exe.config";
			
			// Set our event.
			fileSystemWatcher.Changed += new FileSystemEventHandler(fileSystemWatcher_Changed);

			// It would be smart to actually enable this now.
			fileSystemWatcher.EnableRaisingEvents = true;
		}

		/// <summary>
		/// Grab the settings from our config file.
		/// </summary>
		private void getSettings()
		{
			// Generate the settings from our config file.
			AppSettingsReader settings = new AppSettingsReader();

			// Grabby grab our settings.
			url = (string)settings.GetValue("url", typeof(string));
			refreshTimeout = (int)settings.GetValue("refreshTimeout", typeof(int));
			numberOfDaysBeforeWarning = (int)settings.GetValue("numberOfDaysBeforeWarning", typeof(int));
			balloonTimeout = (int)settings.GetValue("balloonTimeout", typeof(int));
			logLevel = (LogLevelType)Enum.Parse(typeof(LogLevelType), (string)settings.GetValue("logLevel", typeof(string)));
			displayBugIds = (bool)settings.GetValue("displayBugIds", typeof(bool));
			logFileName = (string)settings.GetValue("logFileName", typeof(string));
		}

		/// <summary>
		/// Start the timer to refresh status.
		/// </summary>
		private void setUpTimer()
		{
			// Standard setup.
			refreshTimer.Enabled = true;
			refreshTimer.Interval = refreshTimeout * 60 * 1000;
			refreshTimer.Tick += new EventHandler(refreshTimer_Tick);

			// Actually start the timer.
			refreshTimer.Start();
		}
		
		/// <summary>
		/// Refresh the status of the bugs.
		/// </summary>
		private void refreshStatus()
		{
			if (forcedRefresh)
			{
				log("Forced refresh.", LogLevelType.MildlyVerbose);
			}
			else
			{
				log("Refreshing status.", LogLevelType.MildlyVerbose);
			}

			balloonTip = new StringBuilder();
			balloonTitle = string.Empty;
			
			// Grab the content by scrapping the html from the url we supply.
			string content = getUrlContent(url);

			// Parse the content we just scrapped.
			parseContent(content);
		}

		/// <summary>
		/// Parse the content that we scrapped and store our bugs in a nice object.
		/// </summary>
		/// <param name="content">Content from the web</param>
		private void parseContent(string content)
		{
			List<Bug> bugs = new List<Bug>();
			Regex bugsContentRegex = new Regex(@"show_bug\.cgi\?id\=(?<id>\d+).+?(?<priority>P\d).+?(?<status>NEW|ASSI).+?class=summary\>\<a.+?\>(?<summary>[^\<\/a\>]).+?class=eta\>.+?(?<eta>\d{4}\-\d{2}\-\d{2})", RegexOptions.Compiled);
			Regex bugsFoundRegex = new Regex(@"(?<bugsFound>\d+)\s+bugs\s+found\.", RegexOptions.Compiled);

			// An easy way to grab the total bugs we know about.
			// We probably don't need to do this, I guess because I use the next stuff.
			if (bugsFoundRegex.IsMatch(content))
			{
				Match bugsFoundMatch = bugsFoundRegex.Match(content);
				string bugsFound = bugsFoundMatch.Groups["bugsFound"].Value;

				// Set our balloon title.
				balloonTitle = string.Format("{0} bug{1} found!",
								bugsFound,
								bugsFound == "0" ? "" : "s");

				log(bugsFound + " bugs found.", LogLevelType.Verbose);
			}

			// Grab all of the bugs' data and store it.
			if (bugsContentRegex.IsMatch(content))
			{
				foreach (Match bugsContentMatch in bugsContentRegex.Matches(content))
				{
					// Grab the bug content and store it for later.
					int id = !string.IsNullOrEmpty(bugsContentMatch.Groups["id"].Value) ? int.Parse(bugsContentMatch.Groups["id"].Value) : -1;
					string priority = !string.IsNullOrEmpty(bugsContentMatch.Groups["priority"].Value) ? bugsContentMatch.Groups["priority"].Value : "P0";
					BugStatusType status = !string.IsNullOrEmpty(bugsContentMatch.Groups["status"].Value) ? (BugStatusType)Enum.Parse(typeof(BugStatusType), bugsContentMatch.Groups["status"].Value) : BugStatusType.NEW;
					string summary = !string.IsNullOrEmpty(bugsContentMatch.Groups["summary"].Value) ? bugsContentMatch.Groups["summary"].Value : string.Empty;
					DateTime eta = DateTime.MinValue;

					// New bugs and bugs with no ETA are stored as "0000-00-00" which is pretty lame. I get around it here.
					if (!string.IsNullOrEmpty(bugsContentMatch.Groups["eta"].Value) &&
						!bugsContentMatch.Groups["eta"].Value.Equals("0000-00-00"))
					{
						eta = DateTime.ParseExact(bugsContentMatch.Groups["eta"].Value, "yyyy-MM-dd", null);
					}

					// Take that bug info and create a bug nifty bug object with it.
					bugs.Add(new Bug(id, priority, status, summary, eta));

					log("Bug " + id + " added.", LogLevelType.Verbose);
				}
			}

			// Create a swell balloon tip now.
			createBalloonTip(bugs);
		}

		/// <summary>
		/// Generate some balloon tip content from our bug information.
		/// </summary>
		/// <param name="bugs">The bugs we know about.</param>
		private void createBalloonTip(List<Bug> bugs) 
		{
			// Append some data to the ballon tip if we have any bugs.
			if (bugs.Count > 0)
			{
				log("We need to look at " + bugs.Count + " bugs.", LogLevelType.Verbose);

				DateTime dateTimeNow = DateTime.Now;
				int newBugs = 0;
				int overdueBugs = 0;
				int warningBugs = 0;

				// Get a count of the bugs we know about.
				foreach (Bug bug in bugs)
				{
					if (bug.Status == BugStatusType.NEW)
					{
						newBugs++;
					}
					// Overdue bugs.
					else if (bug.ETA < dateTimeNow)
					{
						overdueBugs++;
					} 
					// Warning bugs.
					else if (bug.ETA < dateTimeNow.AddDays(numberOfDaysBeforeWarning))
					{
						warningBugs++;
					}
				}

				log("There are " + newBugs + " bugs, " + overdueBugs + " overdue bugs, and " + warningBugs + " warning bugs.", LogLevelType.Verbose);

				// Generate our new "state".
				State currentState = new State(newBugs, overdueBugs, warningBugs);
				
				// Only display our bugs if they have changed status or if a refresh was forced.
				if (forcedRefresh
					|| state != currentState )
				{
					if (forcedRefresh)
					{
						// Not forced anymore.
						forcedRefresh = false;
					}
					else
					{
						log("Bug state has changed.", LogLevelType.MildlyVerbose);
					}

					// Save our "state".
					state = currentState;
					
					// Display a list of bug ids, or just a count.
					if (displayBugIds)
					{
						log("Create our detailed balloon tip of bugs.", LogLevelType.Verbose);

						createDetailedBalloonTip(bugs);
					}
					else
					{
						log("Create our less-detailed balloon tip of bugs.", LogLevelType.Verbose);

						createSparseBalloonTip();
					}
					
					if (balloonTip.ToString().EndsWith(Environment.NewLine))
					{
						balloonTip = balloonTip.Remove(balloonTip.Length - 2, 2);
					}

					// Show our balloon tip content.
					showBalloonTip(balloonTitle, balloonTip.ToString(), ToolTipIcon.None);
				}
			}

			// Refresh our system tray icon no matter what.
			setSystemTrayIcon();
		}

		/// <summary>
		/// Create the balloon tip content with bug counts.
		/// </summary>
		private void createSparseBalloonTip()
		{
			// Our "template" string for our generated content.
			string niceBalloonTip = "{0} {1} bug{2}!";

			// Append our nice string and the count if neccessary.
			if (state.NewBugs > 0)
			{
				balloonTip.Append(string.Format(niceBalloonTip,
					state.NewBugs,
					"new",
					state.NewBugs > 1 ? "s" : string.Empty));

				balloonTip.Append(Environment.NewLine);
			}

			if (state.WarningBugs > 0)
			{
				balloonTip.Append(string.Format(niceBalloonTip,
					state.WarningBugs,
					"warning",
					state.WarningBugs > 1 ? "s" : string.Empty));

				balloonTip.Append(Environment.NewLine);
			}

			if (state.OverdueBugs > 0)
			{
				balloonTip.Append(string.Format(niceBalloonTip,
					state.OverdueBugs,
					"overdue",
					state.OverdueBugs > 1 ? "s" : string.Empty));

				balloonTip.Append(Environment.NewLine);
			}
		}

		/// <summary>
		/// Create the balloon tip content with the actual bug ids listed.
		/// </summary>
		/// <param name="bugs">List of bugs.</param>
		private void createDetailedBalloonTip(List<Bug> bugs)
		{
			DateTime dateTimeNow = DateTime.Now;

			// Store the content for each section of the balloon tip.
			StringBuilder overdueBugsBalloonTip = new StringBuilder();
			StringBuilder warningBugsBalloonTip = new StringBuilder();
			StringBuilder newBugsBalloonTip = new StringBuilder();

			// Our "template" string for our generated content.
			string niceBalloonTip = "{0} bug{1}: ";

			foreach (Bug bug in bugs)
			{
				if (bug.Status == BugStatusType.NEW)
				{
					newBugsBalloonTip.Append(bug.Id + ", ");
				}
				// Overdue bugs.
				else if (bug.ETA < dateTimeNow)
				{
					overdueBugsBalloonTip.Append(bug.Id + ", ");
				}
				// Warning bugs.
				else if (bug.ETA < dateTimeNow.AddDays(numberOfDaysBeforeWarning))
				{
					warningBugsBalloonTip.Append(bug.Id + ", ");
				}
			}

			if (state.NewBugs > 0)
			{
				// Append our nice string to the front.
				balloonTip.Append(string.Format(niceBalloonTip,
					"New",
					state.NewBugs > 1 ? "s" : string.Empty));

				// Append our list of bug ids.
				newBugsBalloonTip = newBugsBalloonTip.Remove(newBugsBalloonTip.Length - 2, 2);
				balloonTip.Append(newBugsBalloonTip.ToString());
				balloonTip.Append(Environment.NewLine);
			}

			if (state.WarningBugs > 0)
			{
				// Append our nice string to the front.
				balloonTip.Append(string.Format(niceBalloonTip,
					"Almost due",
					state.WarningBugs > 1 ? "s" : string.Empty));

				// Append our list of bug ids.
				warningBugsBalloonTip = warningBugsBalloonTip.Remove(warningBugsBalloonTip.Length - 2, 2);
				balloonTip.Append(warningBugsBalloonTip.ToString());
				balloonTip.Append(Environment.NewLine);
			}

			if (state.OverdueBugs > 0)
			{
				// Append our nice string to the front.
				balloonTip.Append(string.Format(niceBalloonTip,
					"Overdue",
					state.OverdueBugs > 1 ? "s" : string.Empty));

				// Append our list of bug ids.
				overdueBugsBalloonTip = overdueBugsBalloonTip.Remove(overdueBugsBalloonTip.Length - 2, 2);
				balloonTip.Append(overdueBugsBalloonTip.ToString());
				balloonTip.Append(Environment.NewLine);
			}
		}

		/// <summary>
		/// Helper method to pop up the balloon tip.
		/// </summary>
		/// <param name="balloonTitle">Balloon title.</param>
		/// <param name="balloonTip">Actual content of the tip.</param>
		/// <param name="icon">Icon.</param>
		private void showBalloonTip(string balloonTitle, string balloonTip, ToolTipIcon icon)
		{
			notifyIcon.ShowBalloonTip(balloonTimeout, balloonTitle, balloonTip, icon);
		}

		/// <summary>
		/// Scrape the content from a url.
		/// </summary>
		/// <param name="url">Url to scrap.</param>
		/// <returns>The content.</returns>
		private string getUrlContent(string url)
		{
			log("Grab our content from " + url + ".", LogLevelType.Verbose);

			// Store our content.
			StringBuilder content = new StringBuilder();
			byte[] buffer = new byte[8192];

			// Setup the objects that do the heavy lifting.
			HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
			HttpWebResponse response = (HttpWebResponse)request.GetResponse();

			// Read the stream.
			Stream resStream = response.GetResponseStream();
			string tempString = null;
			int count = 0;

			// Get all of the content from the stream.
			do
			{
				// Fill the buffer.
				count = resStream.Read(buffer, 0, buffer.Length);

				// Make sure we got some good stuff.
				if (count != 0)
				{
					// Convert bytes to a string.
					tempString = Encoding.ASCII.GetString(buffer, 0, count);
					content.Append(tempString);
				}
			}
			while (count > 0);
			
			if (content.Length == 0)
			{
				log("There was no content. That seems fishy. Maybe check your URL?");
			} 
			else
			{
				log("We have content of length " + content.Length + ".", LogLevelType.Verbose);
			}

			return content.ToString();
		}

#region Events
		void notifyIcon_BalloonTipClicked(object sender, EventArgs e)
		{
			// Open up the url in a browser.
			if (!string.IsNullOrEmpty(url))
			{
				Process process = new Process();
				process.StartInfo.FileName = url;
				process.Start();
			}
		}

		void notifyIcon_MouseClick(object sender, MouseEventArgs e)
		{
			// Show the menu for a right-click.
			if (e.Button == MouseButtons.Right)
			{
				notifyIcon.ContextMenuStrip.Show();
			}
		}

		protected override void OnResize(EventArgs e)
		{
			// Erase the app from the task tray when we minimize.
			if (this.WindowState == FormWindowState.Minimized)
			{
				this.Hide();
			}
			
			base.OnResize(e);
		}

		void notifyIcon_MouseDoubleClick(object sender, MouseEventArgs e)
		{
			if (!this.Visible)
			{
				this.Show();
			}
			else
			{
				this.Hide();
			}
		}

		private void exitMenuItem_Click(object sender, EventArgs e)
		{
			this.Close();
			this.Dispose();

			Application.Exit();
		}

		private void refreshMenuItem_Click(object sender, EventArgs e)
		{
			forcedRefresh = true;
			refreshStatus();
		}

		void refreshTimer_Tick(object sender, EventArgs e)
		{
			refreshStatus();
		}

		void fileSystemWatcher_Changed(object sender, FileSystemEventArgs e)
		{
			log("Config values have changed. Starting a new instance and killing our old one.");
			
			// Start new app.
			Process process = new Process();
			process.StartInfo.FileName = Application.ExecutablePath;
			process.Start();

			// Quit our app.
			Application.Exit();
		}
#endregion
	}
}