using System;
using System.Collections.Generic;
using System.Text;

namespace BugZapper
{
	/// <summary>
	/// Summary description for CurrentState
	/// </summary>
	class State
	{
		private int newBugs = -1;
		private int overdueBugs = -1;
		private int warningBugs = -1;
		
		public State(int newBugs, int overdueBugs, int warningBugs)
		{
			this.newBugs = newBugs;
			this.overdueBugs = overdueBugs;
			this.warningBugs = warningBugs;
		}

		public static bool operator == (State state1, State state2)
		{
			if (state1.GetHashCode() == state2.GetHashCode())
			{
				return true;
			}

			return false;
		}

		public static bool operator != (State state1, State state2)
		{
			if (state1.GetHashCode() != state2.GetHashCode())
			{
				return true;
			}

			return false;
		}

		public override int GetHashCode()
		{
			if (newBugs < 0
				|| warningBugs < 0
				|| overdueBugs < 0)
			{
				return -1;
			}

			string val = string.Format("{0}{1}{2}",
				newBugs,
				warningBugs,
				overdueBugs);

			return int.Parse(val);
		}

		public int NewBugs
		{
			get
			{
				return newBugs;
			}
			set
			{
				newBugs = value;
			}
		}

		public int OverdueBugs
		{
			get
			{
				return overdueBugs;
			}
			set
			{
				overdueBugs = value;
			}
		}

		public int WarningBugs
		{
			get
			{
				return warningBugs;
			}
			set
			{
				warningBugs = value;
			}
		}

		public StatusType Status
		{
			get
			{
				// This should be dependant on what's going down.
				if (overdueBugs > 0)
				{
					return StatusType.OVERDUE;
				}

				if (warningBugs > 0)
				{
					return StatusType.WARNED;
				}

				return StatusType.GOOD;
			}
		}
	}
}
