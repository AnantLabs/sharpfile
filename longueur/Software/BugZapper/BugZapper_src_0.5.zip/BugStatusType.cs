namespace BugZapper
{
	enum BugStatusType
	{
		/// <summary>
		/// New
		/// </summary>
		NEW,
		/// <summary>
		/// Assigned
		/// </summary>
		ASSI,
		/// <summary>
		/// Unconfirmed
		/// </summary>
		UNCO,
		/// <summary>
		/// Resolved
		/// </summary>
		RESO,
		/// <summary>
		/// Closed
		/// </summary>
		CLOS,
		/// <summary>
		/// Reopened
		/// </summary>
		REOP,
		/// <summary>
		/// Verified
		/// </summary>
		VERI
	}
}
