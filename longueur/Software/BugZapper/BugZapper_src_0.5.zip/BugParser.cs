using System.Collections.Generic;
using System.Text;

namespace BugZapper
{
	abstract class BugParser
	{
		// Constants.
		protected const string s = "s";
		protected const string New = "New";
		protected const string Overdue = "Overdue";
		protected const string Warning = "Warning";
		protected const string Normal = "Normal";
		protected const string Ignored = "Ignored";

		// The communal balloon tip.
		protected StringBuilder balloonTip = new StringBuilder();

		/// <summary>
		/// Generates the balloon tip from our state.
		/// </summary>
		/// <param name="state">State of the bugs we know about.</param>
		/// <returns>A balloon tip generated from our state.</returns>
		public StringBuilder CreateBalloonTip(State state, bool showNormalBugs)
		{
			// Do the new bug dance.
			if (state.NewBugs.Count > 0)
			{
				createNewBugsBalloonTip(state.NewBugs);
			}

			// And the same for overdues.
			if (state.OverdueBugs.Count > 0)
			{
				createOverdueBugsBalloonTip(state.OverdueBugs);
			}

			// And we might as well take care of those pesky warnings as well.
			if (state.WarningBugs.Count > 0)
			{
				createWarningBugsBalloonTip(state.WarningBugs);
			}

			// Look at our ignores as well.
			if (state.IgnoredBugs.Count > 0)
			{
				createIgnoredBugsBalloonTip(state.IgnoredBugs);
			}

			// If we don't have any content, get some information about the normal bugs.
			if (showNormalBugs)
			{
				createNormalBugsBalloonTip(state.NormalBugs);
			}

			return balloonTip;
		}

		/// <summary>
		/// Generate the balloon tip for the new bugs we know about.
		/// </summary>
		/// <param name="newBugs">New bugs we know.</param>
		protected abstract void createNewBugsBalloonTip(List<Bug> newBugs);

		/// <summary>
		/// Generate the balloon tip for the overdue bugs we know about.
		/// </summary>
		/// <param name="overdueBugs">Overdue bugs we know about.</param>
		protected abstract void createOverdueBugsBalloonTip(List<Bug> overdueBugs);

		/// <summary>
		/// Generate the balloon tip for the warning bugs we know about.
		/// </summary>
		/// <param name="warningBugs">Warning bugs we know about.</param>
		protected abstract void createWarningBugsBalloonTip(List<Bug> warningBugs);

		/// <summary>
		/// Generate the balloon tip for the ignored bugs we know about.
		/// </summary>
		/// <param name="ignoredBugs">Ignored bugs we know about.</param>
		protected abstract void createIgnoredBugsBalloonTip(List<Bug> ignoredBugs);

		/// <summary>
		/// Generate the balloon tip for the normal bugs we know about.
		/// </summary>
		/// <param name="normalBugs">Normal bugs we know about.</param>
		protected abstract void createNormalBugsBalloonTip(List<Bug> normalBugs);
	}
}
