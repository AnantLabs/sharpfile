using System;
using System.Collections.Generic;
using System.Text;

namespace BugZapper.BugParsers
{
	class DetailedBugParser : BugParser
	{
		// Constants.
		private const string balloonTipTemplate = "{0} bug{1}: ";
		private const string comma = ", ";

		/// <summary>
		/// Detailed bug parser to generate a listing of the bug ids in the balloon tip.
		/// </summary>
		public DetailedBugParser()
		{
		}

		protected override void createNewBugsBalloonTip(List<Bug> newBugs)
		{
			createTip(newBugs, New);
		}

		protected override void createOverdueBugsBalloonTip(List<Bug> overdueBugs)
		{
			createTip(overdueBugs, Overdue);
		}

		protected override void createWarningBugsBalloonTip(List<Bug> warningBugs)
		{
			createTip(warningBugs, Warning);
		}

		protected override void createIgnoredBugsBalloonTip(List<Bug> ignoredBugs)
		{
			createTip(ignoredBugs, Ignored);
		}

		protected override void createNormalBugsBalloonTip(List<Bug> normalBugs)
		{
			createTip(normalBugs, Normal);
		}

		private void createTip(List<Bug> bugs, string type)
		{
			// We can assume if we get here that we actually have some warning bugs.
			StringBuilder tempBalloonTip = new StringBuilder();

			foreach (Bug bug in bugs)
			{
				tempBalloonTip.Append(bug.Id);
				tempBalloonTip.Append(comma);
			}

			// Append our nice string to the front.
			balloonTip.Append(string.Format(balloonTipTemplate,
				type,
				bugs.Count > 1 ? s : string.Empty));

			// Append our list of bug ids.
			tempBalloonTip = tempBalloonTip.Remove(tempBalloonTip.Length - 2, 2);

			balloonTip.Append(tempBalloonTip.ToString());
			balloonTip.Append(Environment.NewLine);
		}
	}
}
