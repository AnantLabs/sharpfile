using System;
using System.IO;
using System.Drawing;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using System.Resources;
using System.Text.RegularExpressions;

namespace WinTail
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class TailForm : System.Windows.Forms.Form
	{
		private IContainer components;
		private Button startStopButton;
		private Button browseForFileButton;
		private Button filterButton;
		private Button clearButton;
		private TextBox filenameTextbox;
		private Label filePathLabel;		
		private RichTextBox contentsRichTextbox;
		private StatusStrip statusStrip;
		private ToolStripStatusLabel statusLabel;
		private Button scrollButton;

		// Constants.
		private const string working = "Working...";
		private const string newLine = "\n";
		private const string winTail = "WinTail";

		// Settings.
		private int maximumCharacters = 0;
		private int aggressiveTimeout = 500;
		private bool isAggressivePolling = false;
		private bool scrollOnNewContent = true;
		private bool filterContent = true;
		private string dateTemplate = "M/dd/yyyy - hh:mm:ss";
		private string statusTemplate = "Content from: $lastWrite; Line count: $lineCount; Highlighted line count: $highlightedLineCount";
		private string titleTemplate = winTail;

		private Tail tail;
		private FileInfo fileInfo;
		private List<Filter> filters;
		private Status status = Status.Stopped;
		private Regex newLineRegex = new Regex(newLine, RegexOptions.Compiled);
		private int highlightedLineCount = 0;
		private int lineCount = 0;

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.Run(new TailForm());
		}

		public TailForm()
		{
			// Required for Windows Form Designer support
			InitializeComponent();

			this.filenameTextbox.KeyDown += new KeyEventHandler(filenameTextbox_KeyDown);

			getSettings();
		}

		private void getResourceImages()
		{
			this.startStopButton.Image = (this.status == Status.Stopped ? ApplicationResources.Play : ApplicationResources.Stop);
			this.clearButton.Image = ApplicationResources.Clear;
			this.scrollButton.Image = (this.scrollOnNewContent ? ApplicationResources.Scroll : ApplicationResources.Scroll_Disabled);

			if (this.filters.Count == 0)
			{
				this.filterButton.Image = ApplicationResources.Filter;
				this.filterButton.Enabled = false;
			}
			else if (this.filters.Count > 0)
			{
				this.filterButton.Image = (this.filterContent ? ApplicationResources.Filter : ApplicationResources.Filter_Disabled);
			}

			this.Refresh();
		}

		public void getSettings()
		{
			AppSettingsReader settingsReader = new AppSettingsReader();
			this.maximumCharacters = (int)settingsReader.GetValue("maximumCharacters", typeof(int));
			this.scrollOnNewContent = (bool)settingsReader.GetValue("scrollOnNewContent", typeof(bool));
			this.aggressiveTimeout = (int)settingsReader.GetValue("aggressiveTimeout", typeof(int));
			this.isAggressivePolling = (bool)settingsReader.GetValue("isAggressivePolling", typeof(bool));
			this.filterContent = (bool)settingsReader.GetValue("filterContent", typeof(bool));
			this.dateTemplate = (string)settingsReader.GetValue("dateTemplate", typeof(string));
			this.statusTemplate = (string)settingsReader.GetValue("statusTemplate", typeof(string));
			this.titleTemplate = (string)settingsReader.GetValue("titleTemplate", typeof(string));

			this.filters = (List<Filter>)ConfigurationManager.GetSection("filters");

			if (this.filters == null)
			{
				this.filters = new List<Filter>();
			}

			getResourceImages();
		}

		private void filterAndUpdateContent(string content)
		{
			filterAndUpdateContent(content, true);
		}

		private void filterAndUpdateContent(string content, bool append)
		{
			this.statusLabel.Text = working;
			this.Refresh();

			if (!append)
			{
				clearContent();
			}

			if (this.filterContent &&
				this.filters.Count > 0)
			{
				foreach (string line in newLineRegex.Split(content))
				{
					this.filters.ForEach(delegate(Filter filter)
						{
							if (filter.Regex.IsMatch(line))
							{
								this.contentsRichTextbox.SelectionStart = Contents.Length;
								this.contentsRichTextbox.SelectionBackColor = filter.Color;
								this.highlightedLineCount++;
							}
						});

					if (line.Trim() != string.Empty)
					{
						this.contentsRichTextbox.AppendText(line.Trim() + newLine);
						this.lineCount++;
					}
				}
			}
			else
			{
				this.contentsRichTextbox.AppendText(content);
				this.lineCount = newLineRegex.Matches(Contents).Count;
			}

			if (this.scrollOnNewContent)
			{
				this.contentsRichTextbox.ScrollToCaret();
			}

			this.contentsRichTextbox.Refresh();
			updateStatus();
		}

		private Hashtable getStatusVariableHash()
		{
			Hashtable statusVariableHash = new Hashtable();
			statusVariableHash.Add("$lastWrite", this.fileInfo.LastWriteTime.ToString(this.dateTemplate));
			statusVariableHash.Add("$lineCount", this.lineCount);
			statusVariableHash.Add("$highlightedLineCount", this.highlightedLineCount);
			statusVariableHash.Add("$fileSize", General.GetHumanReadableSize(this.fileInfo.Length));
			statusVariableHash.Add("$fileName", this.fileInfo.Name);
			statusVariableHash.Add("$fullFileName", this.fileInfo.FullName);
			statusVariableHash.Add("$directoryName", this.fileInfo.DirectoryName);

			return statusVariableHash;
		}

		private void updateStatus()
		{
			if (this.fileInfo != null)
			{
				Hashtable statusVariableHash = getStatusVariableHash();
				string statusLine = statusTemplate;
				string titleLine = titleTemplate;

				foreach (string key in statusVariableHash.Keys)
				{
					statusLine = statusLine.Replace(key, statusVariableHash[key].ToString());
					titleLine = titleLine.Replace(key, statusVariableHash[key].ToString());
				}

				this.statusLabel.Text = statusLine;
				this.Text = titleLine;
			}
			else
			{
				this.statusLabel.Text = " ";
				this.Text = winTail;
			}
		}

		private void clearContent()
		{
			this.contentsRichTextbox.Clear();

			this.lineCount = 0;
			this.highlightedLineCount = 0;
		}

		#region overrides
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		protected override void OnResize(EventArgs e)
		{
			this.contentsRichTextbox.Size = new Size(base.Size.Width - 24, base.Size.Height - 90);
			this.contentsRichTextbox.ScrollToCaret();
			this.contentsRichTextbox.Refresh();

			base.OnResize(e);
		}
		#endregion

		#region events
		void filenameTextbox_KeyDown(object sender, KeyEventArgs e)
		{
			if (!string.IsNullOrEmpty(filenameTextbox.Text))
			{
				if (e.KeyCode == Keys.Enter)
				{
					startStopButton_Click(null, null);
				}
			}
		}

		private void browseForFileButton_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog openFileDialog = new OpenFileDialog();

			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				this.filenameTextbox.Text = openFileDialog.FileName;
			}
		}

		private void startStopButton_Click(object sender, System.EventArgs e)
		{
			if (!string.IsNullOrEmpty(filenameTextbox.Text))
			{
				if (this.status == Status.Stopped)
				{
					this.filenameTextbox.Enabled = false;
					this.browseForFileButton.Enabled = false;
					this.statusLabel.Text = working;
					this.startStopButton.Focus();

					status = Status.Started;
					getResourceImages();

					this.fileInfo = new FileInfo(Filename);
					this.tail = new Tail(this.maximumCharacters, this.filenameTextbox.Text, this.isAggressivePolling, this.aggressiveTimeout);

					this.tail.OnNewData += new Tail.OnNewDataHandler(tail_OnNewData);
					this.tail.Start();
				}
				else if (this.status == Status.Started)
				{
					this.filenameTextbox.Enabled = true;
					this.browseForFileButton.Enabled = true;

					status = Status.Stopped;
					getResourceImages();

					this.tail.Stop();
					this.tail = null;
					this.fileInfo = null;
				}
			}
		}

		private void scrollButton_Click(object sender, System.EventArgs e)
		{
			this.scrollOnNewContent = !this.scrollOnNewContent;
			getResourceImages();

			if (this.scrollOnNewContent)
			{
				this.contentsRichTextbox.ScrollToCaret();
			}
		}

		private void clearButton_Click(object sender, System.EventArgs e)
		{
			clearContent();
			updateStatus();
		}

		private void filterButton_Click(object sender, EventArgs e)
		{
			this.filterContent = !this.filterContent;
			getResourceImages();

			this.highlightedLineCount = 0;
			filterAndUpdateContent(Contents, false);
		}

		private void tail_OnNewData(object tailObject, string content)
		{
			int contentLength = Contents.Length + content.Length;

			if (contentLength > this.maximumCharacters
				&& Contents.Length > (contentLength - this.maximumCharacters))
			{
				Contents = Contents.Remove(0, contentLength - this.maximumCharacters);
			}

			filterAndUpdateContent(content);		
		}
		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TailForm));
			this.browseForFileButton = new System.Windows.Forms.Button();
			this.filenameTextbox = new System.Windows.Forms.TextBox();
			this.filePathLabel = new System.Windows.Forms.Label();
			this.clearButton = new System.Windows.Forms.Button();
			this.startStopButton = new System.Windows.Forms.Button();
			this.filterButton = new System.Windows.Forms.Button();
			this.contentsRichTextbox = new System.Windows.Forms.RichTextBox();
			this.statusStrip = new System.Windows.Forms.StatusStrip();
			this.statusLabel = new System.Windows.Forms.ToolStripStatusLabel();
			this.scrollButton = new System.Windows.Forms.Button();
			this.statusStrip.SuspendLayout();
			this.SuspendLayout();
			// 
			// browseForFileButton
			// 
			this.browseForFileButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.browseForFileButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.browseForFileButton.Location = new System.Drawing.Point(564, 9);
			this.browseForFileButton.Name = "browseForFileButton";
			this.browseForFileButton.Size = new System.Drawing.Size(20, 23);
			this.browseForFileButton.TabIndex = 7;
			this.browseForFileButton.Text = "...";
			this.browseForFileButton.Click += new System.EventHandler(this.browseForFileButton_Click);
			// 
			// filenameTextbox
			// 
			this.filenameTextbox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.filenameTextbox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
			this.filenameTextbox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystem;
			this.filenameTextbox.Location = new System.Drawing.Point(169, 11);
			this.filenameTextbox.Name = "filenameTextbox";
			this.filenameTextbox.Size = new System.Drawing.Size(389, 20);
			this.filenameTextbox.TabIndex = 6;
			// 
			// filePathLabel
			// 
			this.filePathLabel.Location = new System.Drawing.Point(136, 14);
			this.filePathLabel.Name = "filePathLabel";
			this.filePathLabel.Size = new System.Drawing.Size(27, 16);
			this.filePathLabel.TabIndex = 5;
			this.filePathLabel.Text = "File:";
			// 
			// clearButton
			// 
			this.clearButton.Location = new System.Drawing.Point(37, 9);
			this.clearButton.Name = "clearButton";
			this.clearButton.Size = new System.Drawing.Size(23, 23);
			this.clearButton.TabIndex = 13;
			this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
			// 
			// startStopButton
			// 
			this.startStopButton.Location = new System.Drawing.Point(8, 9);
			this.startStopButton.Name = "startStopButton";
			this.startStopButton.Size = new System.Drawing.Size(23, 23);
			this.startStopButton.TabIndex = 10;
			this.startStopButton.Click += new System.EventHandler(this.startStopButton_Click);
			// 
			// filterButton
			// 
			this.filterButton.Location = new System.Drawing.Point(66, 9);
			this.filterButton.Name = "filterButton";
			this.filterButton.Size = new System.Drawing.Size(23, 23);
			this.filterButton.TabIndex = 14;
			this.filterButton.UseVisualStyleBackColor = true;
			this.filterButton.Click += new System.EventHandler(this.filterButton_Click);
			// 
			// contentsRichTextbox
			// 
			this.contentsRichTextbox.BackColor = System.Drawing.SystemColors.ControlLightLight;
			this.contentsRichTextbox.Location = new System.Drawing.Point(8, 38);
			this.contentsRichTextbox.Name = "contentsRichTextbox";
			this.contentsRichTextbox.ReadOnly = true;
			this.contentsRichTextbox.Size = new System.Drawing.Size(576, 376);
			this.contentsRichTextbox.TabIndex = 15;
			this.contentsRichTextbox.Text = "";
			this.contentsRichTextbox.WordWrap = false;
			// 
			// statusStrip
			// 
			this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.statusLabel});
			this.statusStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
			this.statusStrip.Location = new System.Drawing.Point(0, 420);
			this.statusStrip.Name = "statusStrip";
			this.statusStrip.Size = new System.Drawing.Size(592, 18);
			this.statusStrip.TabIndex = 16;
			// 
			// statusLabel
			// 
			this.statusLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.statusLabel.Name = "statusLabel";
			this.statusLabel.Size = new System.Drawing.Size(10, 13);
			this.statusLabel.Spring = true;
			this.statusLabel.Text = " ";
			// 
			// scrollButton
			// 
			this.scrollButton.Location = new System.Drawing.Point(95, 9);
			this.scrollButton.Name = "scrollButton";
			this.scrollButton.Size = new System.Drawing.Size(23, 23);
			this.scrollButton.TabIndex = 9;
			this.scrollButton.Click += new System.EventHandler(this.scrollButton_Click);
			// 
			// TailForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(592, 438);
			this.Controls.Add(this.statusStrip);
			this.Controls.Add(this.contentsRichTextbox);
			this.Controls.Add(this.filterButton);
			this.Controls.Add(this.clearButton);
			this.Controls.Add(this.startStopButton);
			this.Controls.Add(this.browseForFileButton);
			this.Controls.Add(this.filenameTextbox);
			this.Controls.Add(this.filePathLabel);
			this.Controls.Add(this.scrollButton);
			this.DoubleBuffered = true;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "TailForm";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.Text = "WinTail";
			this.statusStrip.ResumeLayout(false);
			this.statusStrip.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}
		#endregion

		#region properties
		public string Filename
		{
			get
			{
				return this.filenameTextbox.Text;
			}
		}

		public string Contents
		{
			get
			{
				lock (this)
				{
					return this.contentsRichTextbox.Text;
				}
			}
			set
			{
				lock (this)
				{
					this.contentsRichTextbox.Text = value;
				}
			}
		}
		#endregion
	}
}
