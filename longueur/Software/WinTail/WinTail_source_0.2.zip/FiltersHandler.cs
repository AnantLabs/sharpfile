using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Serialization;
using System.Configuration;

namespace WinTail
{
	/// <summary>
	/// FiltersHandler is a class that allows you to read customized application configuration.
	/// Supposedly this interface is depreciated, but using ConfigurationSection 
	/// doesn't allow me to use a name for an element more than once.
	/// </summary>
	public class FiltersHandler : IConfigurationSectionHandler
	{
		private const string filterConst = "filter";

		public FiltersHandler()
		{
		}

		/// <summary>
		/// This method implements the IConfigurationSectionHandler interface.
		/// This interface defines the contract that all configuration section handlers must 
		/// implement in order to participate in the resolution of configuration settings.
		/// </summary>
		public virtual object Create(object parent, object configContext, XmlNode section)
		{
			List<Filter> list = new List<Filter>();

			foreach (XmlNode node in section.SelectNodes(filterConst))
			{
				XmlNodeReader xmlNodeReader = new XmlNodeReader(node);
				XmlSerializer serializer = new XmlSerializer(typeof(Filter));
				Filter filter = (Filter)serializer.Deserialize(xmlNodeReader);

				list.Add(filter);
			}

			return list;
		}
	}
}
