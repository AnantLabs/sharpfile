using System;
using System.Drawing;

namespace WinTail
{
    /// <summary>
    /// Summary description for General.
    /// </summary>
    public class General
    {
        private General()
        {
        }

		public static Color ConvertStringToColor(string rgb)
		{
			try
			{
				string[] colors = rgb.Split(',');

				int r = int.Parse(colors[0].Trim());
				int g = int.Parse(colors[1].Trim());
				int b = int.Parse(colors[2].Trim());

				return Color.FromArgb(r, g, b);
			}
			catch
			{
				throw new Exception(rgb + " is not a valid color.");
			}
		}

		public static string GetHumanReadableSize(long size)
		{
			//assume that size is in bytes
			if (size > 1073741824)
			{
				double sizeDouble = (Convert.ToDouble(size) / 1024 / 1024 / 1024);
				return GetReadableSize(Convert.ToDouble(Math.Round(sizeDouble, 2))) + " GB";
			}
			else if (size > 1048576)
			{
				double sizeDouble = (Convert.ToDouble(size) / 1024 / 1024);
				return GetReadableSize(Convert.ToDouble(Math.Round(sizeDouble, 2))) + " MB";
			}
			else if (size > 1024)
			{
				double sizeDouble = (Convert.ToDouble(size) / 1024);
				return GetReadableSize(Convert.ToDouble(Math.Round(sizeDouble, 2))) + " KB";
			}
			else
			{
				return GetReadableSize(size) + " B";
			}
		}

		public static string GetReadableSize(double size)
		{
			return GetReadableSize((long)Math.Floor(size)) + GetDecimal(size);
		}

		public static string GetReadableSize(long size)
		{
			char[] origStr = size.ToString().ToCharArray();
			int arrayLength = Convert.ToInt32(Convert.ToDouble(origStr.Length) + Math.Floor(Convert.ToDouble(origStr.Length) / 3));

			if (origStr.Length % 3 == 0)
			{
				arrayLength--;
			}

			if (arrayLength > origStr.Length)
			{
				char[] newStr = new char[arrayLength];

				int j = arrayLength - 1;
				int arrayCount = 0;

				for (int i = origStr.Length - 1; i > -1; i--)
				{
					if (j > -1)
					{
						if (arrayCount % 3 == 0 && arrayCount != 0)
						{
							newStr[j] = ',';
							j--;
						}
						newStr[j] = origStr[i];
						j--;
						arrayCount++;
					}
				}

				return new String(newStr);
			}
			else
			{
				return size.ToString();
			}
		}

		private static string GetDecimal(double val)
		{
			string valStr = val.ToString();
			int index = valStr.IndexOf(".");

			if (index > -1)
			{
				return valStr.Substring(index, valStr.Length - index);
			}
			else
			{
				return "0";
			}
		}
    }
}