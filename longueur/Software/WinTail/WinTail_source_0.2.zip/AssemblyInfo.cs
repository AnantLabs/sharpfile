using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("WinTail")]
[assembly: AssemblyDescription("Just another GUI for the ever-elusive tail -f functionailty on Windows.")]
[assembly: AssemblyVersion("1.0.*")]