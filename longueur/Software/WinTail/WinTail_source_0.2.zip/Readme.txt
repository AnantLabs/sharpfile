WinTail is just another GUI for the ever-elusive tail -f functionailty on Windows.

The application settings available:
maximumCharacters
	Maximum number of characters that are retrieved by tail
isAggressivePolling
	Aggressively polls the file
aggressiveTimeout
	Timeout for the aggressive poll
scrollOnNewContent
	Scroll when new content is received
filterContent
	Filter the content
dateTemplate
	Template used for dates on the status/title line
statusTemplate
	Template used for the status line
		ex: Last update: $lastWrite; # Lines: $lineCount; # Highlighted lines: $highlightedLineCount
titleTemplate
	Template used for the title line
		ex: WinTail [$fullFileName - $fileSize]

The available settings for filters:
regexPattern
	Regular expression that determines what to search for
color
	RGB of the color to highlight a match
		ex: 255,0,255
isCaseSensitive
	Whether the search is case sensitive or not

Date template is the standard C# way of displaying dates; most common listed below (condensed from: http://blog.stevex.net/index.php/string-formatting-in-csharp/):
dd - Day
ddd - Abbreviated day name
dddd - Full day name
hh - 2 digit hour
HH - 2 digit hour, 24hr format
mm - Minute
MM - Month
MMM - Abbreviated month
MMMM - Full month name
ss - Seconds
tt - AM or PM
yy - Year, 2 digits
yyyy - Full year
: -	Separator
/ - Separator

Variables for status line or title templates:
$lastWrite - last time the file was written to
$lineCount - total number of lines
$highlightedLineCount - number of highlighted lines
$fileSize - human-readable size of the file being tailed
$fileName - file name being tailed
$fullFileName - full name of the file being tailed
$directoryName - directory of the file being tailed


Original code from: http://www.codeproject.com/csharp/wintail.asp.
Any suggestions or bug fixes please email mailto:longueur.software@gmail.com.
Project website: http://code.google.com/p/wintailsharp/.
Source can be downloaded from SVN: https://wintailsharp.googlecode.com/svn/trunk/.

This software is released under the GPL 2.0. 
The license should be included in the package or visit http://www.gnu.org/copyleft/gpl.html for more information.