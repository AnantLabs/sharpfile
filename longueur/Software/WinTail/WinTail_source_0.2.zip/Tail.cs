using System;
using System.IO;
using System.Text;
using System.Timers;

namespace WinTail
{
	public class Tail
	{
		public delegate void OnNewDataHandler(object sender, string newData);
		public event OnNewDataHandler OnNewData;

		private FileSystemWatcher fileSystemWatcher = null;
		private Timer timer;
		private string filename = string.Empty;
		private long previousSeekPosition;
		private int maximumCharacters = 0;
		private int aggressiveTimeout = 0;
		private bool isAggressivePolling = false;

		public Tail(int maximumCharacters, string filename)
			: this(maximumCharacters, filename, false, 0)
		{
		}

		public Tail(int maximumCharacters, string filename, bool isAggressivePolling, int aggressiveTimeout)
		{
			this.maximumCharacters = maximumCharacters;
			this.filename = filename;
			this.isAggressivePolling = isAggressivePolling;
			this.aggressiveTimeout = aggressiveTimeout;
		}

		public void Start()
		{
			FileInfo targetFile = new FileInfo(this.filename);
			this.previousSeekPosition = 0;

			if (this.isAggressivePolling)
			{
				this.timer = new Timer();
				this.timer.Interval = this.aggressiveTimeout;
			}
			else
			{
				setupWatcher(targetFile);
			}

			if (!targetFile.Exists)
			{
				if (this.isAggressivePolling)
				{
					setupWatcher(targetFile);
				}

				this.fileSystemWatcher.Created += new FileSystemEventHandler(fileSystemWatcher_Created);
				this.fileSystemWatcher.Renamed += new RenamedEventHandler(fileSystemWatcher_Renamed);
				this.fileSystemWatcher.EnableRaisingEvents = true;
			}
			else
			{
				getFileContents();
				startMonitoring();
			}
		}

		public void Stop()
		{
			if (this.isAggressivePolling)
			{
				this.timer.Enabled = false;
				this.timer.Stop();
				this.timer.Dispose();
			}
			else
			{
				this.fileSystemWatcher.EnableRaisingEvents = false;
				this.fileSystemWatcher.Dispose();
			}
		}

		private void setupWatcher(FileInfo targetFile)
		{
			this.fileSystemWatcher = new FileSystemWatcher();
			this.fileSystemWatcher.IncludeSubdirectories = false;
			this.fileSystemWatcher.Path = targetFile.DirectoryName;
			this.fileSystemWatcher.Filter = targetFile.Name;
		}

		private void startMonitoring()
		{
			if (this.isAggressivePolling)
			{
				timer.Elapsed += new ElapsedEventHandler(timer_Elapsed);
				timer.Enabled = true;
				timer.Start();
			}
			else
			{
				this.fileSystemWatcher.Changed += new FileSystemEventHandler(fileSystemWatcher_Changed);
				this.fileSystemWatcher.EnableRaisingEvents = true;
			}
		}

		private void getFileContents()
		{
			// Read from current seek position to end of file.
			StringBuilder sb = new StringBuilder();
			byte[] bytesRead = new byte[this.maximumCharacters];
			int numBytes = 0;

			using (FileStream fs = new FileStream(this.filename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
			{
				if (fs.Length > this.maximumCharacters)
				{
					this.previousSeekPosition = fs.Length - this.maximumCharacters;
				}

				this.previousSeekPosition = (int)fs.Seek(this.previousSeekPosition, SeekOrigin.Begin);
				numBytes = fs.Read(bytesRead, 0, this.maximumCharacters);
			}

			this.previousSeekPosition += numBytes;

			for (int i = 0; i < numBytes; i++)
			{
				sb.Append((char)bytesRead[i]);
			}

			// Call delegates with the string if there is content.
			if (sb.Length > 0)
			{
				this.OnNewData(this, sb.ToString());
			}
		}

		#region events
		void fileSystemWatcher_Created(object sender, FileSystemEventArgs e)
		{
			startMonitoring();
		}

		void fileSystemWatcher_Renamed(object sender, RenamedEventArgs e)
		{
			startMonitoring();
		}

		private void timer_Elapsed(object sender, ElapsedEventArgs e)
		{
			getFileContents();
		}

		private void fileSystemWatcher_Changed(object source, FileSystemEventArgs e)
		{
			getFileContents();
		}
		#endregion
	}
}