using System;
using System.Collections.Generic;
using System.Text;

namespace WinTail
{
	enum Status
	{
		Started,
		Stopped
	}
}
