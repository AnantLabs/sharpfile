using System;
using System.Drawing;
using System.Xml.Serialization;
using System.Text.RegularExpressions;

namespace WinTail
{
	[XmlRoot("filter")]
	public class Filter
	{
		private string regexPattern;
		private bool isCaseSensitive = false;
		private string colorStr = string.Empty;
		private Regex regex;
		private Color color;

		public Filter()
		{
		}

		[XmlAttribute("regexPattern")]
		public string RegexPattern
		{
			get
			{
				return this.regexPattern;
			}
			set
			{
				this.regexPattern = value;
			}
		}

		[XmlAttribute("isCaseSensitive")]
		public bool IsCaseSensitive
		{
			get
			{
				return this.isCaseSensitive;
			}
			set
			{
				this.isCaseSensitive = value;
			}
		}

		[XmlAttribute("color")]
		public string ColorStr
		{
			get
			{
				return this.colorStr;
			}
			set
			{
				this.colorStr = value;
			}
		}

		public Regex Regex
		{
			get
			{
				if (regex == null)
				{
					if (this.isCaseSensitive)
					{
						regex = new Regex(this.regexPattern, RegexOptions.Compiled);
					}
					else
					{
						regex = new Regex(this.regexPattern, RegexOptions.Compiled | RegexOptions.IgnoreCase);
					}
				}

				return this.regex;
			}
		}

		public Color Color
		{
			get
			{
				if (this.color.Name.Equals("0"))
				{
					this.color = General.ConvertStringToColor(this.colorStr);
				}

				return this.color;
			}
		}
	}
}
