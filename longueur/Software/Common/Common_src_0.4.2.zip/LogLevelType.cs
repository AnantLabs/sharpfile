namespace Common
{
	public enum LogLevelType
	{
		ErrorsOnly = 0,
		MildlyVerbose = 1,
		Verbose = 2
	}
}