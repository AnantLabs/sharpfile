namespace Common
{
	public enum DynamicComparerType
	{
		ASC,
		DESC
	}
}
