using System;
using System.Drawing;

namespace Common
{
    /// <summary>
    /// Summary description for General.
    /// </summary>
    public class General
    {
        private General()
        {
        }

        public static bool IsInt(string val)
        {
            try
            {
                int ret = int.Parse(val);
                return true;
            }
            catch { }

            return false;
        }

        public static bool IsInt(object val)
        {
            try
            {
                int ret = Convert.ToInt32(val);
                return true;
            }
            catch { }

            return false;
        }

        public static string GetExt(string file)
        {
            if (file.LastIndexOf(".") > -1)
            {
                return file.Substring(file.LastIndexOf("."), file.Length - (file.LastIndexOf(".")));
            }

            return string.Empty;
        }

        public static string GetSubString(string val, int length)
        {
            if (!IsNullOrEmpty(val) && val.Length > length)
            {
                return val.Substring(0, length) + "...";
            }
            else
            {
                return val;
            }
        }

        public static bool IsNullOrEmpty(string val)
        {
            if (string.IsNullOrEmpty(val))
            {
                return true;
            }

            return false;
        }

		public static bool IsNullOrEmpty(object val)
		{
			if (val == null || val.ToString() == string.Empty)
			{
				return true;
			}

			return false;
		}

		public static Color ConvertStringToColor(string rgb)
		{
			try
			{
				string[] colors = rgb.Split(',');

				int r = int.Parse(colors[0].Trim());
				int g = int.Parse(colors[1].Trim());
				int b = int.Parse(colors[2].Trim());

				return Color.FromArgb(r, g, b);
			}
			catch
			{
				throw new Exception(rgb + " is not a valid color.");
			}
		}

		public static string GetHumanReadableSize(string value)
		{
			double size;

			if (double.TryParse(value, out size))
			{
				//assume that size is in bytes
				if (size > 1073741824)
				{
					size = size / 1024 / 1024 / 1024;
					return getReadableSize(Math.Round(size, 2)) + " GB";
				}
				else if (size > 1048576)
				{
					size = size / 1024 / 1024;
					return getReadableSize(Math.Round(size, 2)) + " MB";
				}
				else if (size > 1024)
				{
					size = size / 1024;
					return getReadableSize(Math.Round(size, 2)) + " KB";
				}
				else
				{
					return getReadableSize(size) + " B";
				}
			}

			return "n/a";
		}

		public static string getReadableSize(double size)
		{
			return getReadableSize((long)Math.Floor(size)) + getDecimal(size);
		}

		public static string getReadableSize(long size)
		{
			char[] origStr = size.ToString().ToCharArray();
			double origStrLength = Convert.ToDouble(origStr.Length);

			int arrayLength = Convert.ToInt32(origStrLength + Math.Floor(origStrLength / 3));

			if (origStrLength % 3 == 0)
			{
				arrayLength--;
			}

			if (arrayLength > origStrLength)
			{
				char[] newStr = new char[arrayLength];

				int j = arrayLength - 1;
				int arrayCount = 0;

				for (int i = origStr.Length - 1; i > -1; i--)
				{
					if (j > -1)
					{
						if (arrayCount % 3 == 0 && arrayCount != 0)
						{
							newStr[j] = ',';
							j--;
						}
						newStr[j] = origStr[i];
						j--;
						arrayCount++;
					}
				}

				return new string(newStr);
			}
			else
			{
				return size.ToString();
			}
		}

		private static string getDecimal(double val)
		{
			string valStr = val.ToString();
			int index = valStr.IndexOf(".");

			if (index > -1)
			{
				return valStr.Substring(index, valStr.Length - index);
			}
			else
			{
				return "0";
			}
		}
    }
}