using System;
using System.Collections;

namespace Common
{
    /// <summary>
    /// Summary description for CaseInsensitiveArrayList
    /// </summary>
    public class CaseInsensitiveArrayList : ArrayList
    {
        public CaseInsensitiveArrayList()
        {
        }

        public override bool Contains(object item)
        {
            for (int i = 0; i < this.Count; i++)
            {
                if (string.Compare(this[i].ToString(), item.ToString(), true) == 0)
                {
                    return true;
                }
            }

            return false;
        }
    }
}
