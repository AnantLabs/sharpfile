using System;
using System.IO;
using System.Text;

namespace Common
{
	public class Tail
	{
		public delegate void OnNewDataHandler(object sender, string newData);
		public event OnNewDataHandler OnNewData;

		private FileSystemWatcher fileSystemWatcher = null;
		private string filename = string.Empty;
		private long previousSeekPosition;
		private int maxBytes = 1024 * 16;

		public Tail(string filename)
		{
			this.filename = filename;
		}

		public void Start()
		{
			FileInfo targetFile = new FileInfo(this.filename);

			this.previousSeekPosition = 0;

			this.fileSystemWatcher = new FileSystemWatcher();
			this.fileSystemWatcher.IncludeSubdirectories = false;
			this.fileSystemWatcher.Path = targetFile.DirectoryName;
			this.fileSystemWatcher.Filter = targetFile.Name;

			if (!targetFile.Exists)
			{
				this.fileSystemWatcher.Created += new FileSystemEventHandler(TargetFile_Created);
				this.fileSystemWatcher.EnableRaisingEvents = true;
			}
			else
			{
				TargetFile_Changed(null, null);
				StartMonitoring();
			}
		}

		public void Stop()
		{
			this.fileSystemWatcher.EnableRaisingEvents = false;
			this.fileSystemWatcher.Dispose();
		}

		public string ReadFullFile()
		{
			using (StreamReader streamReader = new StreamReader(this.filename))
			{
				return streamReader.ReadToEnd();
			}
		}

		public void StartMonitoring()
		{
			this.fileSystemWatcher.Changed += new FileSystemEventHandler(TargetFile_Changed);
			this.fileSystemWatcher.EnableRaisingEvents = true;
		}

		#region events
		public void TargetFile_Created(object source, FileSystemEventArgs e)
		{
			StartMonitoring();
		}

		public void TargetFile_Changed(object source, FileSystemEventArgs e)
		{
			// Read from current seek position to end of file.
			byte[] bytesRead = new byte[maxBytes];
			int numBytes = 0;

			using (FileStream fs = new FileStream(this.filename, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
			{
				if (fs.Length > maxBytes)
				{
					this.previousSeekPosition = fs.Length - maxBytes;
				}

				this.previousSeekPosition = (int)fs.Seek(this.previousSeekPosition, SeekOrigin.Begin);
				numBytes = fs.Read(bytesRead, 0, maxBytes);
			}

			this.previousSeekPosition += numBytes;

			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < numBytes; i++)
			{
				sb.Append((char)bytesRead[i]);
			}

			// Call delegates with the string.
			this.OnNewData(this, sb.ToString());
		}
		#endregion

		public int MaxBytes
		{
			get { return this.maxBytes; }
			set { this.maxBytes = value; }
		}
	}
}