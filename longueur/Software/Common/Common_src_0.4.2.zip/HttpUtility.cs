using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Text;
using System.Net;
using System.IO;

namespace Common
{
	/// <summary>
	/// Summary description for Http
	/// </summary>
	public class HttpUtility
	{
		public HttpUtility()
		{
		}

		public static string GetHttpResponse(string uri)
		{
			// Ripped from: http://www.csharp-station.com/HowTo/HttpWebFetch.aspx.
			StringBuilder sb = new StringBuilder();
			byte[] buf = new byte[8192];

			HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
			HttpWebResponse response = (HttpWebResponse)request.GetResponse();

			Stream resStream = response.GetResponseStream();
			string tempString = null;
			int count = 0;

			do
			{
				// Fill the buffer with data.
				count = resStream.Read(buf, 0, buf.Length);

				// Make sure we read some data.
				if (count != 0)
				{
					// Translate from bytes to ASCII text.
					tempString = Encoding.ASCII.GetString(buf, 0, count);
					sb.Append(tempString);
				}
			}
			while (count > 0);

			return sb.ToString();
		}

		public static bool GetHttpResponseImage(string uri, string physicalFile)
		{
			//ripped and modified from: http://www.csharp-station.com/HowTo/HttpWebFetch.aspx
			string file = physicalFile;

			if (File.Exists(file))
			{
				string ext = General.GetExt(file);
				file = file.Insert(file.Length - ext.Length, "_" + Guid.NewGuid().ToString().Substring(0, 5));
			}

			try
			{
				using (FileStream fs = new FileStream(file, FileMode.Create))
				{
					byte[] buf = new byte[1];
					HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);

					using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
					{
						Stream resStream = response.GetResponseStream();
						int count = 0;

						do
						{
							// fill the buffer with data
							count = resStream.Read(buf, 0, buf.Length);

							// make sure we read some data
							if (count != 0)
							{
								fs.Write(buf, 0, buf.Length);
							}
						} while (count > 0);

						fs.Flush();
					}
				}
			}
			catch
			{
				return false;
			}

			return true;
		}
	}
}