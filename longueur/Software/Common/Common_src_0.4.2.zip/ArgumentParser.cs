using System;
using System.Collections;
using System.Collections.Generic;

namespace Common
{
	public class ArgumentParser
	{
		private const string _switch = "-";

		private Hashtable switchArgumentHash;
		private List<string> switchArgumentList;
		private List<string> nonSwitchArgumentList;

		public ArgumentParser(string[] args)
		{
			nonSwitchArgumentList = new List<string>();
			switchArgumentHash = new Hashtable();

			// We should only this if we have some real, live arguments.
			if (args != null &&
				args.Length > 0)
			{
				for (int argIndex = 0; argIndex < args.Length; )
				{
					if (areNextTwoArgumentsValid(args, argIndex))
					{
						string key = args[argIndex];
						string value = args[argIndex + 1];

						switchArgumentHash.Add(key, value);
						argIndex += 2;
					}
					else
					{
						string value = args[argIndex];

						nonSwitchArgumentList.Add(value);
						argIndex += 1;
					}
				}
			}
		}

		private static bool areNextTwoArgumentsValid(string[] args, int argIndex)
		{
			return args.Length > argIndex &&
					!string.IsNullOrEmpty(args[argIndex]) &&
					args[argIndex].StartsWith(_switch) &&
					args.Length > argIndex + 1 &&
					!string.IsNullOrEmpty(args[argIndex + 1]) &&
					!args[argIndex + 1].StartsWith(_switch);
		}

		public string this[string key]
		{
			get
			{
				return switchArgumentHash[key].ToString().Trim();
			}
		}

		public List<string> SwitchArguments
		{
			get
			{
				if (switchArgumentList == null)
				{
					switchArgumentList = new List<string>(switchArgumentHash.Keys.Count);

					foreach (string key in switchArgumentHash.Keys)
					{
						switchArgumentList.Add(key);
					}
				}

				return switchArgumentList;
			}
		}

		public List<string> NonSwitchArguments
		{
			get
			{
				return nonSwitchArgumentList;
			}
		}
	}
}