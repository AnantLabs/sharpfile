Common
Version 0.4.2.0

A common repository for code I use across more than one project.

The source code for this program is available under the GPL; a copy of the license should be distributed with the executable. 
The source can be downloaded from http://www.longueur.org/software/.

There are no warranties, implicit or otherwise, included with this software. 
Run at your own risk. And read the source to send me suggestions or improvements.