using System;
using System.Resources;
using System.Reflection;

namespace Common
{
	public class Resources
	{
		private ResourceManager resourceManager = new ResourceManager("Common.ApplicationResources", Assembly.GetExecutingAssembly());

		public Resources()
		{
		}

		public object this[string name]
		{
			get
			{
				return resourceManager.GetObject(name);
			}
		}
	}
}
