using System;
using System.Web.Security;

namespace Common
{
    /// <summary>
    /// Summary description for Security.
    /// </summary>
    public class Security
    {
		public enum PasswordFormatType
		{
			sha1
		}

		// Hide the constructor.
        private Security()
        {
        }

		/// <summary>
		/// Encrypt the string using the default encryption (SHA1).
		/// </summary>
		/// <param name="unencryptedString"></param>
		/// <returns></returns>
		public static string Encrypt(string unencryptedString)
		{
			return Encrypt(unencryptedString, PasswordFormatType.sha1);
		}

		/// <summary>
		/// Encrypt the string.
		/// </summary>
		/// <param name="unencryptedString"></param>
		/// <returns></returns>
		public static string Encrypt(string unencryptedString, PasswordFormatType passwordFormatType)
		{
			return FormsAuthentication.HashPasswordForStoringInConfigFile(unencryptedString, passwordFormatType.ToString());
		}
    }
}